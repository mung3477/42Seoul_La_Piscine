/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/26 13:15:22 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/30 11:01:39 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	is_space_ex03(unsigned char c)
{
	return (('\t' <= c && c <= '\r') || c == ' ');
}

int	ft_atoi(char *str)
{
	int	ret;
	int	idx;
	int	sign;

	ret = 0;
	idx = 0;
	sign = 1;
	while (is_space_ex03((unsigned char)str[idx]))
		idx += 1;
	while (str[idx] == '+' || str[idx] == '-')
		if (str[idx++] == '-')
			sign *= -1;
	while ('0' <= str[idx] && str[idx] <= '9')
		ret = ret * 10 + str[idx++] - '0';
	return (ret * sign);
}
