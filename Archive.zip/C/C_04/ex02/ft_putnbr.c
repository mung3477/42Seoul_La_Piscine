/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/26 11:35:28 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/26 20:50:58 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	count_digit(int nb)
{
	int	digit;

	digit = 0;
	while (nb > 0)
	{
		digit += 1;
		nb /= 10;
	}
	return (digit);
}

void	stringfy(int nb, char *stringfied)
{
	int	digit;
	int	idx;

	digit = count_digit(nb);
	idx = 0;
	while (idx < digit)
	{
		stringfied[digit - 1 - idx] = nb % 10 + '0';
		nb /= 10;
		idx += 1;
	}
	write(1, stringfied, digit);
}

void	ft_putnbr(int nb)
{
	char	stringfied[10];

	if (nb < 0)
	{
		write(1, "-", 1);
		if (nb == -2147483648)
			write (1, "2147483648", 10);
		else
			stringfy((nb * -1), stringfied);
	}
	else if (nb == 0)
		write(1, "0", 1);
	else
		stringfy(nb, stringfied);
}
