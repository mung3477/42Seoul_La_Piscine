/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/26 14:50:49 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/30 10:57:12 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	putnbr_base(long long nb, char *base, int base_length)
{
	char	output[32];
	int		idx;

	idx = 0;
	while (nb >= 0)
	{
		output[idx++] = base[nb % base_length];
		nb /= base_length;
		if (nb == 0)
			break ;
	}
	while (--idx >= 0)
		write(1, &output[idx], 1);
}

int	is_sign(char c)
{
	return (c == '+' || c == '-');
}

int	base_check_ex04(char *base)
{
	char	used[256];
	int		idx;

	idx = 0;
	idx = 0;
	while (idx < 256)
		used[idx++] = 0;
	idx = 0;
	while (base[idx] != '\0')
	{
		if (used[(unsigned char)base[idx]] || is_sign(base[idx]))
			return (0);
		else
			used[(unsigned char)base[idx++]] = 1;
	}
	if (idx == 0 || idx == 1)
		return (0);
	return (idx);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int				base_length;
	long long		nb;

	base_length = base_check_ex04(base);
	if (!base_length)
		return ;
	nb = (long long)nbr;
	if (nbr < 0)
	{
		write(1, "-", 1);
		nb *= -1;
	}
	putnbr_base(nb, base, base_length);
}
