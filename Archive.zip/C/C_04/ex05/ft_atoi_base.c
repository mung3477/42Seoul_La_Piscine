/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/26 15:48:25 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/30 11:20:38 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	is_space(unsigned char c)
{
	return (('\t' <= c && c <= '\r') || c == ' ');
}

// returns the length of base string.
int	base_check(char *base, int *base_table)
{
	int		idx;
	char	cur;

	idx = -1;
	while (++idx < 256)
		base_table[idx] = -1;
	idx = -1;
	while (base[++idx] != '\0')
	{
		cur = base[idx];
		if (cur == '+' || cur == '-' || is_space((unsigned char)cur))
			return (0);
		else if (base_table[(unsigned char)cur] != -1)
			return (0);
		base_table[(unsigned char)cur] = idx;
	}
	if (idx == 0 || idx == 1)
		return (0);
	return (idx);
}

int	char_to_base_10(char *str, int *base_table, int base_len)
{
	int	ret;
	int	sign;
	int	idx;

	ret = 0;
	sign = 1;
	idx = 0;
	while (is_space((unsigned char)str[idx]))
		idx += 1;
	while (str[idx] == '+' || str[idx] == '-')
	{
		if (str[idx] == '-')
			sign *= -1;
		idx += 1;
	}
	while (base_table[(unsigned char)str[idx]] != -1)
		ret = ret * base_len + base_table[(unsigned char)str[idx++]];
	return (ret * sign);
}

/*
 *	base_table uses index as character's ascii code.
 *	it stores a number that index character represents.
 *	since characters in base string doesn't collide, 
 *	max length of base is 256(characters in C).
 *	table -> Input: Ascii character / Output: number
 */
int	ft_atoi_base(char *str, char *base)
{
	int	base_table[256];
	int	base_len;

	base_len = base_check(base, base_table);
	if (!base_len)
		return (0);
	return (char_to_base_10(str, base_table, base_len));
}
