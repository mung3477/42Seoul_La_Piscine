/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_count_if.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/02 12:15:07 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/06 16:29:30 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_count_if(char **tab, int length, int (*f)(char*))
{
	int	idx;
	int	count;

	idx = 0;
	count = 0;
	while (idx < length)
	{
		count += (f(tab[idx]) != 0);
		idx += 1;
	}
	return (count);
}
