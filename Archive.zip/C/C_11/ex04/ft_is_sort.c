/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/02 14:36:54 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/07 15:01:16 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	int			idx;
	long long	sort_form;
	long long	cmp_result;

	idx = 1;
	sort_form = 0;
	while (idx < length)
	{
		cmp_result = f(tab[idx - 1], tab[idx]);
		if (cmp_result * sort_form < 0)
			return (0);
		if (cmp_result)
			sort_form = cmp_result;
		idx += 1;
	}
	return (1);
}
