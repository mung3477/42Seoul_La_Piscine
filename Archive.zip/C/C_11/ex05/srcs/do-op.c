/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   do-op.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/02 14:55:43 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/06 16:32:20 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_atoi(char *str);
void	ft_putnbr(int nb);
int		add(int a, int b);
int		sub(int a, int b);
int		mul(int a, int b);
int		div(int a, int b);
int		mod(int a, int b);

typedef enum e_operator
{
	PLUS,
	MINUS,
	MULTIPLY,
	DIVIDE,
	MODULO,
	WRONG
}				t_operator;

typedef int	(*t_calc_func)(int, int);

int	ft_atoop(char *str)
{
	const char	operators[5] = {'+', '-', '*', '/', '%'};
	t_operator	op;
	int			idx;

	op = WRONG;
	if (str[1] != '\0')
		return (op);
	idx = 0;
	while (idx < 5)
	{
		if (str[0] == operators[idx])
		{
			op = idx;
			break ;
		}
		idx += 1;
	}
	return (op);
}

int	is_wrong_args(t_operator op, int right)
{
	if (op == WRONG)
		return (write(1, "0\n", 2));
	else if (op == DIVIDE && right == 0)
		return (write(1, "Stop : division by zero\n", 24));
	else if (op == MODULO && right == 0)
		return (write(1, "Stop : modulo by zero\n", 22));
	else
		return (0);
}

int	main(int argc, char *argv[])
{
	int					left;
	t_operator			op;
	int					right;
	int					result;
	const t_calc_func	calc[5] = {&add, &sub, &mul, &div, &mod};

	if (argc != 4)
		return (0);
	left = ft_atoi(argv[1]);
	op = ft_atoop(argv[2]);
	right = ft_atoi(argv[3]);
	if (is_wrong_args(op, right))
		return (0);
	result = calc[op](left, right);
	ft_putnbr(result);
	write(1, "\n", 1);
	return (0);
}
