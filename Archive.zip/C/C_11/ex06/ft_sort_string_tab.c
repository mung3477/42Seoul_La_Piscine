/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_string_tab.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/02 17:45:33 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/02 18:06:58 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp_ex06(char *str1, char *str2)
{
	int	idx;

	idx = 0;
	while (str1[idx] && str2[idx] && (str1[idx] == str2[idx]))
		idx += 1;
	return ((unsigned char)str1[idx] - (unsigned char)str2[idx]);
}

int	word_count(char **tab)
{
	int	idx;

	idx = 0;
	while (tab[idx])
		idx += 1;
	return (idx);
}

void	ft_sort_string_tab(char **tab)
{
	char		*temp;
	int			sorted;
	int			idx;
	const int	entire = word_count(tab);

	sorted = 0;
	while (sorted <= entire)
	{
		idx = 1;
		while (idx < entire - sorted)
		{
			if (ft_strcmp_ex06((tab[idx - 1]), (tab[idx])) > 0)
			{
				temp = tab[idx - 1];
				tab[idx - 1] = tab[idx];
				tab[idx] = temp;
			}
			idx += 1;
		}
		sorted += 1;
	}
}
