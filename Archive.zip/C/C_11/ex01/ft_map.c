/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/02 12:02:23 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/06 16:29:01 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_map(int *tab, int length, int (*f)(int))
{
	int	*results;
	int	idx;

	if (!length)
		return (0);
	results = (int *)malloc(sizeof(int) * length);
	if (!results)
		return (0);
	idx = -1;
	while (++idx < length)
		results[idx] = f(tab[idx]);
	return (results);
}
