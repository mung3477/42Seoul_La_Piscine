/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/21 22:11:11 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/21 22:46:08 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	temp;
	int	dst;
	int	src;

	dst = 0;
	while (dst < size / 2)
	{
		src = size - 1 - dst;
		temp = tab[src];
		tab[src] = tab[dst];
		tab[dst++] = temp;
	}
}
