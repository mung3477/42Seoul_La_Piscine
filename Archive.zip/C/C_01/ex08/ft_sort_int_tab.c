/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/21 22:46:37 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/22 11:32:12 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	swap(int *a, int *b)
{
	int	t;

	t = *a;
	*a = *b;
	*b = t;
}

void	ft_sort_int_tab(int *tab, int size)
{
	int	sorted;
	int	last_idx;
	int	idx;

	sorted = 0;
	while (sorted < size)
	{
		idx = 1;
		last_idx = size - 1 - sorted;
		while (idx <= last_idx)
		{
			if (tab[idx - 1] > tab[idx])
				swap(&tab[idx - 1], &tab[idx]);
			idx += 1;
		}
		sorted += 1;
	}
}
