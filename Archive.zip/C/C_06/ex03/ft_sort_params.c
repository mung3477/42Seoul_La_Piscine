/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 16:52:23 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/31 22:02:08 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	compare(char *str1, char *str2)
{
	int	idx;

	idx = 0;
	while ((str1[idx] != '\0' && str2[idx] != '\0') && str1[idx] == str2[idx])
		idx += 1;
	return ((int)((unsigned char)str1[idx] - (unsigned char)str2[idx]));
}

void	print_argv(int argc, char *argv[])
{
	int	idx;
	int	str_idx;

	idx = 0;
	while (++idx <= argc - 1)
	{
		str_idx = 0;
		while (argv[idx][str_idx])
			write(1, &argv[idx][str_idx++], 1);
		write(1, "\n", 1);
	}
}

int	main(int argc, char *argv[])
{
	int		idx;
	int		sorted;
	char	*temp;

	sorted = -1;
	while (++sorted <= argc - 1)
	{
		idx = 1;
		while (++idx <= argc - 1 - sorted)
		{
			if (compare(argv[idx - 1], argv[idx]) > 0)
			{
				temp = argv[idx];
				argv[idx] = argv[idx - 1];
				argv[idx - 1] = temp;
			}
		}
	}
	return (0);
}
