/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 16:40:02 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/31 21:56:03 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char *argv[])
{
	int	idx;
	int	str_idx;

	idx = 0;
	while (++idx < argc)
	{
		str_idx = 0;
		while (argv[idx][str_idx] != '\0')
			write(1, &argv[idx][str_idx++], 1);
		write(1, "\n", 1);
	}
	return (0);
}
