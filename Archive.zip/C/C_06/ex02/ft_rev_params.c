/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 16:48:15 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/31 21:55:31 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char *argv[])
{
	int	idx;
	int	str_idx;

	idx = argc;
	while (0 < --idx)
	{
		str_idx = 0;
		while (argv[idx][str_idx] != '\0')
			write(1, &argv[idx][str_idx++], 1);
		write(1, "\n", 1);
	}
	return (0);
}
