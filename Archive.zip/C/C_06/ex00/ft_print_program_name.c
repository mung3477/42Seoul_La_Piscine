/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_program_name.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 16:26:14 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/30 16:39:40 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char *argv[])
{
	const int	name_idx = argc - 1;
	int			idx;

	idx = 0;
	while (argv[name_idx][idx] != '\0')
	{
		write(1, &argv[name_idx][idx], 1);
		idx += 1;
	}
	write(1, "\n", 1);
	return (0);
}
