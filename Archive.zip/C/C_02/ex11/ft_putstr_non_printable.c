/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/23 17:56:26 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/24 21:27:28 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_hex(unsigned char c)
{
	unsigned char	hex_char;

	if (c < 10)
		hex_char = c + '0';
	else
		hex_char = c - 10 + 'a';
	write(1, &hex_char, 1);
}

void	print_hex_ver(unsigned char c)
{
	write(1, "\\", 1);
	print_hex(c / 16);
	print_hex(c % 16);
}

int	is_printable(char c)
{
	return (' ' <= c && c <= '~');
}

void	ft_putstr_non_printable(char *str)
{
	int	idx;

	idx = 0;
	while (str[idx] != '\0')
	{
		if (!is_printable(str[idx]))
			print_hex_ver((unsigned char)str[idx]);
		else
			write(1, &str[idx], 1);
		idx += 1;
	}
}
