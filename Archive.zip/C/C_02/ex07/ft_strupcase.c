/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/23 12:24:48 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/23 12:50:39 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strupcase(char *str)
{
	unsigned int	idx;

	idx = 0;
	while (str[idx] != '\0')
	{
		if ('a' <= str[idx] && str[idx] <= 'z')
			str[idx] = str[idx] + 'A' - 'a';
		idx += 1;
	}	
	return (str);
}
