/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/23 13:57:08 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/24 21:25:15 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*	
 *	strlcpy() takes the full size of the destination buffer and
 *	guarantee NUL-termination if there is room.  Note that room for the NUL
 *	should be included in dstsize.
 *
 *	strlcpy() copies up to dstsize - 1 characters from the string src to dst,
 *	NUL-terminating the result if dstsize is not 0.
 *	
 *	strlcpy() function returns the total 
 *	length of the string they tried to create.
 *	For strlcpy() that means the length of src.
 */
unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	idx;
	unsigned int	src_length;

	src_length = 0;
	while (src[src_length] != '\0')
		src_length += 1;
	idx = 0;
	if (size)
	{
		while ((idx < size - 1) && (idx < src_length))
		{
			dest[idx] = src[idx];
			idx += 1;
		}
		dest[idx] = '\0';
	}
	return (src_length);
}
