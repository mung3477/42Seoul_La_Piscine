/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/22 11:38:55 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/24 20:59:07 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 *	The stpcpy() and strcpy() functions copy the string src to dst (including
 *	the terminating `\0' character.)
 *
 *	The source and destination strings should not overlap, as the behavior is
 *	undefined.
 *
 *	The strcpy() and strncpy() functions return dst.  
 */
char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i])
	{
		dest[i] = src[i];
		i += 1;
	}
	dest[i] = src[i];
	return (dest);
}
