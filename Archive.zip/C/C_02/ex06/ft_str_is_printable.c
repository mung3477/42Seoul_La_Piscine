/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/22 16:51:32 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/22 17:02:19 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	char_is_printable(char c)
{
	return (' ' <= c && c <= '~');
}

int	ft_str_is_printable(char *str)
{
	int	idx;
	int	is_printable;

	idx = 0;
	is_printable = 1;
	while (str[idx] != '\0')
	{
		if (!char_is_printable(str[idx]))
		{
			is_printable = 0;
			break ;
		}
		idx += 1;
	}
	return (is_printable);
}
