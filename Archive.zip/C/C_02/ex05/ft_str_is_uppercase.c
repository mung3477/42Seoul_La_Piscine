/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/22 16:47:14 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/22 16:50:57 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	char_is_uppercase(char c)
{
	return ('A' <= c && c <= 'Z');
}

int	ft_str_is_uppercase(char *str)
{
	int	idx;
	int	is_uppercase;

	idx = 0;
	is_uppercase = 1;
	while (str[idx] != '\0')
	{
		if (!char_is_uppercase(str[idx]))
		{
			is_uppercase = 0;
			break ;
		}
		idx += 1;
	}
	return (is_uppercase);
}
