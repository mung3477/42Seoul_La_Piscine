/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_memory.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/23 19:42:26 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/25 11:36:17 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

/*
 *	Address of 64bit system is 8bytes (64bits).
 *	Hexadecimal 1 digit is 4bit.
 *	Therefore, Address of a pointer should be 16 digit hexadecimal.
 *
 *	Input: 10base, Output: 16base
 */
void	print_memory_address(long long address)
{
	char	address_str[16];
	char	cur_digit;
	int		digit;

	digit = 0;
	while (++digit <= 16)
	{
		cur_digit = address % 16;
		if (cur_digit < 10)
			cur_digit = cur_digit + '0';
		else
			cur_digit = cur_digit - 10 + 'a';
		address_str[16 - digit] = cur_digit;
		address /= 16;
	}
	write(1, address_str, 16);
	write(1, ": ", 2);
}

/*
 *	Unsigned char can contain from 0 to 255, which is 0xFF.
 */
void	print_char_in_hex(unsigned char c)
{
	unsigned char	in_hex[2];
	int				idx;

	in_hex[0] = c / 16;
	in_hex[1] = c % 16;
	idx = 0;
	while (idx <= 1)
	{
		if (in_hex[idx] < 10)
			in_hex[idx] = in_hex[idx] + '0';
		else
			in_hex[idx] = in_hex[idx] - 10 + 'a';
		idx += 1;
	}
	write(1, in_hex, 2);
}

void	print_content_in_hex(unsigned char *str, unsigned int size)
{
	unsigned int	idx;
	int				printed;

	idx = -1;
	printed = 0;
	while (++idx < size)
	{
		print_char_in_hex(*(str + idx));
		printed += 1;
		if (printed == 2)
		{
			write(1, " ", 1);
			printed = 0;
		}
	}
	while (idx++ < 16)
	{
		write(1, "  ", 2);
		printed += 1;
		if (printed == 2)
		{
			write(1, " ", 1);
			printed = 0;
		}
	}
}

void	print_content(unsigned char *str, unsigned int size)
{
	unsigned char	idx;

	idx = 0;
	while (idx < size)
	{
		if (!(' ' <= *(str + idx) && *(str + idx) <= '~'))
			write(1, ".", 1);
		else
			write(1, str + idx, 1);
		idx += 1;
	}
	write(1, "\n", 1);
}

void	*ft_print_memory(void *addr, unsigned int size)
{
	unsigned int	idx;
	unsigned int	print_size;

	idx = 0;
	if (size)
	{
		while (idx < size)
		{
			if (size - idx < 16)
				print_size = size - idx;
			else
				print_size = 16;
			print_memory_address((long long)(addr + idx));
			print_content_in_hex((unsigned char *)(addr + idx), print_size);
			print_content((unsigned char *)(addr + idx), print_size);
			idx += 16;
		}
	}
	return (addr);
}
