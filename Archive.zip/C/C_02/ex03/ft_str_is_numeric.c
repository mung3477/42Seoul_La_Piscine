/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/22 16:26:35 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/22 16:39:29 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	char_is_numeric(char c)
{
	return ('0' <= c && c <= '9');
}

int	ft_str_is_numeric(char *str)
{
	int	idx;
	int	is_numeric;

	idx = 0;
	is_numeric = 1;
	while (str[idx] != '\0')
	{
		if (!char_is_numeric(str[idx]))
		{
			is_numeric = 0;
			break ;
		}
		idx += 1;
	}
	return (is_numeric);
}
