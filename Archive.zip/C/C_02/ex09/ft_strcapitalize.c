/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/23 13:04:26 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/25 11:37:10 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	is_alpha_numeric(char c)
{
	int	is_alpha;
	int	is_numeric;

	is_alpha = (('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z'));
	is_numeric = ('0' <= c && c <= '9');
	return (is_alpha || is_numeric);
}

void	make_upper(char *str, int idx)
{
	if ('a' <= str[idx] && str[idx] <= 'z')
		str[idx] = str[idx] - 'a' + 'A';
}

void	make_lower(char *str, int idx)
{
	if ('A' <= str[idx] && str[idx] <= 'Z')
		str[idx] = str[idx] - 'A' + 'a';
}

char	*ft_strcapitalize(char *str)
{
	int		word_start;
	int		idx;
	char	cur_char;

	word_start = 1;
	idx = -1;
	while (str[++idx] != '\0')
	{
		cur_char = str[idx];
		if (is_alpha_numeric(cur_char))
		{
			if (word_start)
			{
				make_upper(str, idx);
				word_start = 0;
			}
			else
				make_lower(str, idx);
		}
		else
			word_start = 1;
	}
	return (str);
}
