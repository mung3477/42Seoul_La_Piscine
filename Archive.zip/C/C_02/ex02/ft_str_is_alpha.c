/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/22 15:06:07 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/24 21:09:15 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	char_is_alpha(char c)
{
	return (('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z'));
}

int	ft_str_is_alpha(char *str)
{
	int	idx;
	int	is_alpha;

	idx = 0;
	is_alpha = 1;
	while (str[idx] != '\0')
	{
		if (!char_is_alpha(str[idx]))
		{
			is_alpha = 0;
			break ;
		}
		idx += 1;
	}
	return (is_alpha);
}
