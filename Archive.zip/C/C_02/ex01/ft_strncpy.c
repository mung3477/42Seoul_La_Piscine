/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/22 13:22:45 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/24 21:01:00 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 *	strcpy() functions copy the string src to dst (including
 *	the terminating `\0' character.)
 *
 *	The strncpy() function copies at most len characters from src
 *	into dst.  If src is less than len characters long, the remainder of dst
 *	is filled with `\0' characters.  Otherwise, dst is not terminated.
 *	
 *	The source and destination strings should not overlap, as the behavior is
 *	undefined.
 *
 *	The strcpy() and strncpy() functions return dst.
 *
 *	case 1: src.length == n
 *		until src[i] is null char copy items
 *	case 2: src.length < n
 *		until src[i] is null char copy items
 *		fill dest[i to n] with null char
 *	case 3: src.length > n
 *		until i < n copy items
 */
char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n && src[i] != '\0')
	{
		dest[i] = src[i];
		i += 1;
	}
	while (i < n)
		dest[i++] = '\0';
	return (dest);
}
