/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/22 16:39:51 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/22 16:46:48 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	char_is_lowercase(char c)
{
	return ('a' <= c && c <= 'z');
}

int	ft_str_is_lowercase(char *str)
{
	int	idx;
	int	is_lowercase;

	idx = 0;
	is_lowercase = 1;
	while (str[idx] != '\0')
	{
		if (!char_is_lowercase(str[idx]))
		{
			is_lowercase = 0;
			break ;
		}
		idx += 1;
	}
	return (is_lowercase);
}
