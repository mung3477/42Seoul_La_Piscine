/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/31 11:12:24 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/01 13:22:34 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	is_space(char c);
int	is_sign(char c);
int	is_banned_char(char c);

int	base_check(char *base, int *base_table)
{
	int				idx;
	unsigned char	cur;

	idx = -1;
	while (++idx < 256)
		base_table[idx] = -1;
	idx = -1;
	while (base[++idx] != '\0')
	{
		cur = (unsigned char)base[idx];
		if (base_table[cur] != -1 || is_banned_char(base[idx]))
			return (0);
		else
			base_table[cur] = idx;
	}
	if (idx == 0 || idx == 1)
		return (0);
	return (idx);
}

long long	ft_atoi_base(char *nbr, int base_from_len, int *base_from_table)
{
	int				idx;
	long long		result;
	int				sign;
	unsigned char	cur;

	idx = 0;
	while (is_space(nbr[idx]))
		idx += 1;
	sign = 1;
	while (is_sign(nbr[idx]))
		if (nbr[idx++] == '-')
			sign *= -1;
	result = 0;
	cur = (unsigned char)nbr[idx];
	while (base_from_table[cur] != -1)
	{
		result = result * base_from_len + base_from_table[cur];
		cur = (unsigned char)nbr[++idx];
	}
	return (result * sign);
}

int	digit_count_base(long long num, int base_len)
{
	int	digit;

	if (num == 0)
		return (1);
	digit = 0;
	while (num > 0)
	{
		digit += 1;
		num /= base_len;
	}
	return (digit);
}

char	*ft_itoa_base(long long num, char *base_to, int base_to_len)
{
	const int	is_neg = (num < 0);
	int			converted_num_digit;
	char		*result;
	int			idx;

	if (is_neg)
		num *= -1;
	converted_num_digit = digit_count_base(num, base_to_len);
	result = (char *)malloc(sizeof(char) * (converted_num_digit + 1 + is_neg));
	if (is_neg)
		result[0] = '-';
	idx = converted_num_digit + is_neg;
	result[idx] = '\0';
	while (1)
	{
		result[--idx] = base_to[num % base_to_len];
		num /= base_to_len;
		if (num == 0)
			break ;
	}
	return (result);
}

char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	int			base_from_table[256];
	int			base_to_table[256];
	long long	converted_10_base;
	const int	base_from_len = base_check(base_from, base_from_table);
	const int	base_to_len = base_check(base_to, base_to_table);

	if (!base_from_len || !base_to_len)
		return (0);
	converted_10_base = ft_atoi_base(nbr, base_from_len, base_from_table);
	return (ft_itoa_base(converted_10_base, base_to, base_to_len));
}
