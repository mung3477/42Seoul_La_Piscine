/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/31 15:49:18 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/31 20:56:54 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	count_words(char *str, char is_split[256])
{
	int	idx;
	int	word_num;

	idx = 0;
	word_num = 0;
	while (str[idx])
	{
		while (is_split[(unsigned char)str[idx]])
			idx += 1;
		if (str[idx])
			word_num += 1;
		while (!is_split[(unsigned char)str[idx]] && str[idx])
			idx += 1;
	}
	return (word_num);
}

void	ft_strlcpy(char *dst, char *src, int size)
{
	int	idx;

	idx = -1;
	while (++idx < size - 1)
		dst[idx] = src[idx];
	dst[idx] = '\0';
}

void	wordcpy(char **ret, char *str, char is_split[256], int *err)
{
	int	idx;
	int	word_idx;
	int	word_end;

	idx = 0;
	word_idx = 0;
	while (1)
	{
		while (is_split[(unsigned char)str[idx]])
			idx += 1;
		if (!str[idx])
			break ;
		word_end = idx;
		while (!is_split[(unsigned char)str[word_end]] && str[word_end])
			word_end += 1;
		ret[word_idx] = (char *)malloc(sizeof(char) * (word_end - idx + 1));
		if (!ret[word_idx])
		{
			*err = 1;
			break ;
		}
		ft_strlcpy(ret[word_idx], str + idx, word_end - idx + 1);
		word_idx += 1;
		idx = word_end;
	}
}

char	**ft_split(char *str, char *charset)
{
	char	is_split[256];
	char	**ret;
	int		idx;
	int		word_count;
	int		err;

	err = 0;
	idx = -1;
	while (++idx < 256)
		is_split[idx] = 0;
	idx = -1;
	while (charset[++idx] != '\0')
		is_split[(unsigned char)charset[idx]] = 1;
	word_count = count_words(str, is_split);
	printf("%d\n", word_count);
	ret = (char **)malloc(sizeof(char *) * (word_count + 1));
	if (!ret)
		return (0);
	ret[word_count] = 0;
	if (word_count)
		wordcpy(ret, str, is_split, &err);
	if (err)
		return (0);
	return (ret);
}
