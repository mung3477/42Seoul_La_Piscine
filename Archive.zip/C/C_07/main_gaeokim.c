/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main07.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gaeokim <gaeokim@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/25 15:01:39 by gaeokim           #+#    #+#             */
/*   Updated: 2022/06/01 13:08:01 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ex00/ft_strdup.c"
#include "ex01/ft_range.c"
#include "ex02/ft_ultimate_range.c"
#include "ex03/ft_strjoin.c"
#include "ex04/ft_convert_base.c"
#include "ex04/ft_convert_base2.c"
#include "ex05/ft_split.c"

#include <stdlib.h>
#include <stdio.h>
#include <string.h> 

int main()
{
	{
		printf("======ex00======\n");
		char str[50] = "hello world";
		printf("%s %s\n", strdup(str), ft_strdup(str));
	}
	{
		printf("======ex01======\n");
		int *arr = ft_range(3, 5);
		int i = 0;
		while (arr[i] != '\0')
		{
			printf("%d ", arr[i]);
			i++;
		}
		printf("\n");
		arr = ft_range(5, 5);
		printf("%p\n", arr);
	}
	{
		printf("======ex02======\n");
		int *arr;
		printf("%d\n", ft_ultimate_range(&arr, 3, 5));
		for (int i = 0; i < 2; i++)
			printf("%d ", arr[i]);
		printf("\n");
		printf("%p -->\n", arr);
		printf("%d\n", ft_ultimate_range(&arr, 0, 0));
		printf("%p\n", arr);
	}
	{
		printf("======ex03======\n");
		char *strs[] = {"hello","4242", "world","gaeon", "nojam"};
		char sep[10] = " : ";
		char *result;
		int	size = 5;
		printf("%s\n", ft_strjoin(size, strs, sep));
		printf("%s\n", result = ft_strjoin(0, strs, sep));
		free(result);
	}
	{
		printf("======ex04======\n");
		char str[30] = "  \t\r\f   --+-babc ";
		char base_form[10] = "aab";
		char base_to[10] = "01234";
		printf("%s\n", ft_convert_base(str, base_form, base_to));
	}
	{
		printf("======ex05======\n");
		char charset[2] = " ";
		//char str[100] = "hello!world!!@happy#thurs^&day";
		char str2[10] = "\t     \t \t";
		char **strs = ft_split(str2, charset);
		int i = 0;
		while (strs[i] != NULL)
		{
			printf("%s\n", strs[i]);
			i++;
		}
	}
}
