/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/26 21:25:45 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/31 20:58:37 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int			*ret;
	int			idx;
	const int	size = max - min;

	if (min >= max)
		return (0);
	ret = (int *)malloc(sizeof(int) * size);
	if (!ret)
		return (0);
	idx = -1;
	while (++idx < size)
		ret[idx] = min + idx;
	return (ret);
}
