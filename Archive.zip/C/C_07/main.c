#include <stdio.h>

// #include "ex00/ft_strdup.c"
#include "ex01/ft_range.c"
#include "ex02/ft_ultimate_range.c"

int main(void)
{
    {
        printf("====ex01====\n");
        int *arr;
        arr = ft_range(0, 10);
        for (int i = 0; i < 10; i++)
            printf("%d ", arr[i]);
    }
    {
        printf("\n====ex02====\n");
        int *arr;
        ft_ultimate_range(&arr, 0, 10);
        for (int i = 0; i < 10; i++)
            printf("%d ", arr[i]);
    }
}