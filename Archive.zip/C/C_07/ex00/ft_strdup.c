/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/26 21:09:35 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/01 13:10:29 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

/*
 * The strdup() function allocates sufficient memory 
 * for a copy of the string s1, does the copy, 
 * and returns a pointer to it.  
 *
 * The pointer may subsequently be used 
 * as an argument to the function free(3).
 *
 * If insufficient memory is available, 
 * NULL is returned and errno is set to ENOMEM.
 */
char	*ft_strdup(char *src)
{
	char	*dst;
	int		size;
	int		idx;

	size = 0;
	idx = 0;
	while (src[size])
		size += 1;
	dst = (char *)malloc(sizeof(char) * (size + 1));
	if (!dst)
		return (0);
	while (idx < size)
	{
		dst[idx] = src[idx];
		idx += 1;
	}
	dst[idx] = '\0';
	return (dst);
}
