/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 21:55:40 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/01 13:10:44 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	idx;

	idx = 0;
	while (str[idx] != '\0')
		idx += 1;
	return (idx);
}

int	count_result_size(int size, char **strs, char *sep)
{
	int			idx;
	int			result_size;
	const int	sep_size = ft_strlen(sep);

	idx = -1;
	result_size = 0;
	while (++idx < size)
		result_size += ft_strlen(strs[idx]);
	result_size += sep_size * (size - 1) + 1;
	return (result_size);
}

void	ft_strcpy(char *dst, int *dst_idx, char *src)
{
	int	src_idx;

	src_idx = 0;
	while (src[src_idx] != '\0')
	{
		dst[*dst_idx] = src[src_idx];
		*dst_idx += 1;
		src_idx += 1;
	}
}

void	ft_join(char *dst, int size, char **strs, char *sep)
{
	int	dst_idx;
	int	idx;

	idx = -1;
	dst_idx = 0;
	while (++idx < size - 1)
	{
		ft_strcpy(dst, &dst_idx, strs[idx]);
		ft_strcpy(dst, &dst_idx, sep);
	}
	ft_strcpy(dst, &dst_idx, strs[size - 1]);
	dst[dst_idx] = '\0';
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*dst;
	int		result_size;

	if (size < 0)
		return (0);
	else if (size)
	{
		result_size = count_result_size(size, strs, sep);
		dst = (char *)malloc(sizeof(char) * result_size);
		if (!dst)
			return (0);
		ft_join(dst, size, strs, sep);
	}
	else
	{
		dst = (char *)malloc(sizeof(char) * 1);
		if (!dst)
			return (0);
		dst[0] = '\0';
	}
	return (dst);
}
