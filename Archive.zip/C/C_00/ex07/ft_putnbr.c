/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/20 10:20:14 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/21 21:11:31 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	digit_count(int nb)
{
	int	digit;

	digit = 0;
	while (nb > 0)
	{
		digit += 1;
		nb /= 10;
	}
	return (digit);
}

void	compose_string(int nb, char *stringfied)
{
	int	digit;
	int	i;

	digit = digit_count(nb);
	i = 0;
	while (i < digit)
	{
		stringfied[digit - 1 - i] = nb % 10 + '0';
		nb /= 10;
		i += 1;
	}
	write(1, stringfied, digit);
}

void	ft_putnbr(int nb)
{
	char	stringfied[10];

	if (nb < 0)
	{
		write(1, "-", 1);
		if (nb == -2147483648)
			write(1, "2147483648", 10);
		else
		{
			nb *= -1;
			compose_string(nb, stringfied);
		}
	}
	else if (nb == 0)
		write(1, "0", 1);
	else
		compose_string(nb, stringfied);
}
