/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/20 10:47:23 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/24 10:44:29 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_comb(char *comb, int n)
{
	char	max_char;

	max_char = 10 - n + '0';
	write(1, comb, n);
	if (comb[0] != max_char)
		write(1, ", ", 2);
}

void	make_comb(char cur_char, int put_idx, char *comb, int n)
{
	char	next_char;
	char	max_char;

	if (put_idx == n)
		print_comb(comb, n);
	else
	{
		max_char = 10 - n + put_idx + '0';
		while (cur_char <= max_char)
		{
			comb[put_idx] = cur_char;
			next_char = cur_char + 1;
			make_comb(next_char, put_idx + 1, comb, n);
			cur_char += 1;
		}
	}
}

void	ft_print_combn(int n)
{
	char	comb[9];

	make_comb('0', 0, comb, n);
}
