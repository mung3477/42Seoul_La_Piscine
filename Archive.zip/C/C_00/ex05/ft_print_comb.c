/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/19 16:55:59 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/24 10:45:45 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_comb(char *comb)
{
	char	max_char;

	max_char = 10 - 3 + '0';
	write(1, comb, 3);
	if (comb[0] != max_char)
		write(1, ", ", 2);
}

void	make_comb(int put_idx, char cur_char, char *comb)
{
	char	max_char;
	char	next_char;

	if (put_idx == 3)
		print_comb(comb);
	else
	{
		max_char = 10 - 3 + put_idx + '0';
		while (cur_char <= max_char)
		{
			comb[put_idx] = cur_char;
			next_char = cur_char + 1;
			make_comb(put_idx + 1, next_char, comb);
			cur_char = cur_char + 1;
		}
	}
}

void	ft_print_comb(void)
{
	char	comb[3];
	char	cur_char;

	cur_char = '0';
	make_comb(0, cur_char, comb);
}
