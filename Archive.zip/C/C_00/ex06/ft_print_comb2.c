/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/19 21:58:29 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/24 10:46:53 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_comb(char *comb, int last)
{
	write(1, comb, 5);
	if (!last)
		write(1, ", ", 2);
}

void	make_comb(int left, int right, char *comb, int last)
{
	comb[0] = left / 10 + '0';
	comb[1] = left % 10 + '0';
	comb[3] = right / 10 + '0';
	comb[4] = right % 10 + '0';
	print_comb(comb, last);
}

void	ft_print_comb2(void)
{
	char	comb[5];
	int		left;
	int		right;

	comb[2] = ' ';
	left = 0;
	while (left < 99)
	{
		right = left + 1;
		while (right < 100)
		{
			make_comb(left, right, comb, (left == 98 && right == 99));
			right++;
		}
		left++;
	}
}
