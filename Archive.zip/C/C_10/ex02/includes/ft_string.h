/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_string.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/06 20:53:13 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 18:27:02 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_STRING_H
# define FT_STRING_H
# include "ft_queue.h"

int		strlen_ex02(char *str);
void	strcpy_ex02(unsigned char *dst, t_node *head);

#endif
