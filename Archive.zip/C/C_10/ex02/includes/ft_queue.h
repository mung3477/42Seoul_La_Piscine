/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_queue.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/06 17:26:40 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 18:26:52 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_QUEUE_H
# define FT_QUEUE_H

typedef struct s_node
{
	unsigned char	data;
	struct s_node	*next;
}				t_node;

int				insert(t_node **head, unsigned char data, const int tail_len);
unsigned char	*extract_str(t_node *head);
void			delete_all(t_node *head);

#endif
