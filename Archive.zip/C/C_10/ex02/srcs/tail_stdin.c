/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tail_stdin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/06 17:35:26 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/09 12:38:21 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include "ft_queue.h"
#include "ft_string.h"

void	tail_stdin(const int tail_len)
{
	unsigned char	buff[1];
	char			read_one_after_eof;
	unsigned char	*output;
	t_node			*head;

	head = 0;
	while (1)
	{
		read_one_after_eof = 0;
		while (read(0, buff, 1) > 0)
		{
			read_one_after_eof = 1;
			if (!insert(&head, buff[0], tail_len))
				return ;
		}
		if (!read_one_after_eof || buff[0] == '\n')
			break ;
	}
	output = extract_str(head);
	write(1, output, strlen_ex02((char *)output));
	free(output);
}
