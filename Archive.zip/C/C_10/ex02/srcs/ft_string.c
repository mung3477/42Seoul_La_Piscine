/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_string.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/06 20:51:02 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 18:28:18 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_queue.h"

int	strlen_ex02(char *str)
{
	int	idx;

	idx = 0;
	while (str[idx])
		idx += 1;
	return (idx);
}

void	strcpy_ex02(unsigned char *dst, t_node *head)
{
	int		i;
	t_node	*cur;

	i = 0;
	cur = head;
	while (cur)
	{
		dst[i++] = cur->data;
		cur = cur->next;
	}
	dst[i] = '\0';
}
