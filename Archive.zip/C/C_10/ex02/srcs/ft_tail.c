/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tail.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/06 17:19:36 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/09 12:27:50 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	tail_stdin(const int tail_len);
void	tail_file(const int tail_len, char *prog_name, char *pathname, int mul);
int		ft_atoi(char *num_str);
int		print_errors(char *prog_name, int mode, char *number_str);

int	main(int argc, char *argv[])
{
	int	i;
	int	tail_len;

	if (argc == 1)
		return (0);
	else if (argc == 2)
		return (print_errors(argv[0], 0, argv[2]));
	i = 3;
	tail_len = ft_atoi(argv[2]);
	if (tail_len < 0)
		return (print_errors(argv[0], 1, argv[2]));
	if (argc == 3)
		tail_stdin(tail_len);
	else
		while (argv[i])
			tail_file(tail_len, argv[0], argv[i++], argc != 4);
	return (0);
}
