/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tail_file.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/06 20:29:08 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 18:49:43 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <unistd.h>
#include <libgen.h>
#include <string.h>
#include <sys/errno.h>
#include "ft_queue.h"
#include "ft_string.h"

void	print_tail(t_node *head, char *pathname, int mul);
int		print_errmsg(char *prog_name, char *file_name);
int		read_file(const int tail_len, char *prog_name, \
						char *pathname, t_node **p_head);

void	tail_file(const int tail_len, char *prog_name, char *pathname, int mul)
{
	static int	first_success = 1;
	t_node		*head;

	head = 0;
	if (!read_file(tail_len, prog_name, pathname, &head))
		return ;
	if (!first_success)
		write(1, "\n", 1);
	else
		first_success = 0;
	print_tail(head, pathname, mul);
}

int	read_file(const int tail_len, char *prog_name, \
					char *pathname, t_node **p_head)
{
	const int	fd = open(pathname, O_RDONLY);
	int			read_result;
	char		buff[1];

	if (fd == -1)
		return (print_errmsg(basename(prog_name), pathname));
	while (1)
	{
		read_result = read(fd, buff, 1);
		if (read_result == -1)
		{
			if (errno == 21)
				break ;
			return (print_errmsg(basename(prog_name), pathname));
		}
		else if (read_result == 0)
			break ;
		if (!insert(p_head, (unsigned char)buff[0], tail_len))
		{
			close(fd);
			return (0);
		}
	}
	close(fd);
	return (1);
}

void	print_tail(t_node *head, char *pathname, int mul)
{
	unsigned char	*tail;
	int				i;

	if (mul)
	{
		write(1, "==> ", 4);
		write(1, pathname, strlen_ex02(pathname));
		write(1, " <==\n", 5);
	}
	tail = extract_str(head);
	if (!tail || !tail[0])
		return ;
	i = 0;
	while (tail[i])
		i += 1;
	write(1, tail, i);
	return ;
}

int	print_errmsg(char *prog_name, char *file_name)
{
	char	*errmsg;

	errmsg = strerror(errno);
	write(2, prog_name, strlen_ex02(prog_name));
	write(2, ": ", 2);
	write(2, file_name, strlen_ex02(file_name));
	write(2, ": ", 2);
	write(2, errmsg, strlen_ex02(errmsg));
	write(2, "\n", 1);
	return (0);
}
