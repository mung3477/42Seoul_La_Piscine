/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_errors.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/08 17:26:09 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 17:41:18 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <libgen.h>
#include "ft_string.h"

int	print_errors(char *prog_name, int mode, char *number_str)
{
	const char	*prog_basename = basename(prog_name);

	write(2, prog_basename, strlen_ex02((char *)prog_basename));
	write(2, ": ", 2);
	if (mode == 0)
		return (write(2, "option requires an argument -- c\n", 33) == -1);
	else if (mode == 1)
	{
		write(2, "illegal offset -- ", 18);
		write(2, number_str, strlen_ex02(number_str));
		return (write(2, "\n", 1) == -1);
	}
	return (0);
}
