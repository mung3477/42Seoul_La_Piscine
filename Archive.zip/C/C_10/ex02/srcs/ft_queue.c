/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_queue.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/06 17:36:19 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 18:27:56 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_queue.h"
#include "ft_string.h"

t_node	*set_string_to_tail_len(t_node **head, const int tail_len)
{
	t_node	*last;
	t_node	*temp;
	int		cur_len;

	last = *head;
	if (last == 0)
		return (0);
	cur_len = 1;
	while (last->next)
	{
		last = last->next;
		cur_len += 1;
	}
	if (cur_len == tail_len)
	{
		temp = *head;
		*head = (*head)->next;
		temp->next = 0;
		free(temp);
	}
	return (last);
}

int	insert(t_node **head, unsigned char data, const int tail_len)
{
	t_node	*last;
	t_node	*new;

	if (!tail_len)
		return (1);
	last = set_string_to_tail_len(head, tail_len);
	new = (t_node *)malloc(sizeof(t_node) * 1);
	if (!new)
	{
		delete_all(*head);
		return (0);
	}
	new->data = data;
	new->next = 0;
	if (last)
		last->next = new;
	else
		*head = new;
	return (1);
}

unsigned char	*extract_str(t_node *head)
{
	unsigned char	*result;
	int				length;
	t_node			*cur;

	length = 0;
	cur = head;
	while (cur)
	{
		length += 1;
		cur = cur->next;
	}
	result = (unsigned char *)malloc(sizeof(unsigned char) * (length + 1));
	if (!result)
	{
		delete_all(head);
		return (0);
	}
	strcpy_ex02(result, head);
	delete_all(head);
	return (result);
}

void	delete_all(t_node *head)
{
	t_node	*prev;
	t_node	*cur;

	prev = head;
	cur = head;
	while (cur)
	{
		cur = cur->next;
		prev->next = 0;
		free(prev);
		prev = cur;
	}
}
