/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_hexdump.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 11:50:03 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 19:41:52 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_string.h"

void	hexdump_stdin(int c_flag);
void	hexdump_files(char *prog_name, char *file_names[], int c_flag, int mul);

int	main(int argc, char *argv[])
{
	if (argc == 1)
		hexdump_stdin(0);
	else if (argc == 2)
	{
		if (!strcmp_ex03(argv[1], "-C"))
			hexdump_stdin(1);
		else
			hexdump_files(argv[0], argv, 0, 0);
	}
	else
	{
		if (!strcmp_ex03(argv[1], "-C"))
			hexdump_files(argv[0], argv, 1, (argv[3] != 0));
		else
			hexdump_files(argv[0], argv, 0, 1);
	}
	return (0);
}
