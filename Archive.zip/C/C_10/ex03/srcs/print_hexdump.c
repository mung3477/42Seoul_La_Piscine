/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_hexdump.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 17:15:43 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 19:46:14 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include <sys/errno.h>
#include <string.h>
#include <libgen.h>
#include "ft_queue.h"
#include "ft_string.h"
#include "hexdump_info.h"

void	print_index(long long printed, int remain);
void	print_content_in_hex(const char *str, int c_flag, int length);
void	print_content(const char *str, int length);

void	print_hexdump(t_node **p_head, int c_flag)
{
	int					length;
	const char			*output = extract_str(p_head, &length);
	static long long	printed = 0;

	print_index(printed, 7 + c_flag);
	if (length)
	{
		print_content_in_hex(output, c_flag, length);
		if (c_flag)
		{
			write(1, "  ", 2);
			print_content(output, length);
		}
		printed += length;
		free((void *)output);
	}
	write(1, "\n", 1);
}

void	print_index(long long printed, int remain)
{
	const char	hex[17] = "0123456789abcdef";

	if (remain == 0)
		return ;
	print_index(printed / 16, remain - 1);
	write(1, &hex[printed % 16], 1);
}

void	print_content_in_hex(const char *str, int c_flag, int length)
{
	unsigned char	cur;
	int				printed;
	const char		hex[17] = "0123456789abcdef";

	printed = 0;
	while (printed < length)
	{
		write(1, "  ", 1 + (c_flag && (printed % 8 == 0)));
		cur = (unsigned char)str[printed];
		write(1, &hex[cur / 16], 1);
		write(1, &hex[cur % 16], 1);
		printed += 1;
	}
	while (printed < 16)
	{
		write(1, "  ", 1 + (c_flag && (printed % 8 == 0)));
		write(1, "  ", 2);
		printed += 1;
	}
}

void	print_content(const char *str, int length)
{
	int				i;
	unsigned char	cur;

	write(1, "|", 1);
	i = -1;
	while (++i < length)
	{
		cur = (unsigned char)str[i];
		if (' ' <= cur && cur <= '~')
			write(1, &str[i], 1);
		else
			write(1, ".", 1);
	}
	write(1, "|", 1);
}

void	print_errmsg(t_hexdump_info *info)
{
	const char	*prog_basename = basename(info->prog_name);

	write(2, prog_basename, strlen_ex03((char *)prog_basename));
	write(2, ": ", 2);
	write(2, info->file_name, strlen_ex03(info->file_name));
	write(2, ": ", 2);
	write(2, strerror(errno), strlen_ex03(strerror(errno)));
	write(2, "\n", 1);
}
