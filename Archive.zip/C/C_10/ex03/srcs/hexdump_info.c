/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hexdump_info.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/08 13:42:21 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 13:49:16 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "hexdump_info.h"

t_hexdump_info	*create_hexdump_info(char *prog_name, char *file_name, int mul)
{
	t_hexdump_info	*info;

	info = (t_hexdump_info *)malloc(sizeof(t_hexdump_info) * 1);
	if (!info)
		return (0);
	info->prog_name = prog_name;
	info->file_name = file_name;
	info->multiple_files = mul;
	return (info);
}
