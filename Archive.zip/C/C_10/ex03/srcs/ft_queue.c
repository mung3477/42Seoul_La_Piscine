/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_queue.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 13:40:23 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 19:44:20 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_queue.h"
#include "ft_string.h"

int	insert(t_node **p_head, char data)
{
	t_node	*last;
	t_node	*new;

	new = (t_node *)malloc(sizeof(t_node) * 1);
	if (!new)
	{
		delete_all(p_head);
		return (0);
	}
	new->next = 0;
	new->data = data;
	last = *p_head;
	if (last)
	{
		while (last->next)
			last = last->next;
		last->next = new;
	}
	else
		*p_head = new;
	return (1);
}

//	extract at most 16 characters from the head.
//	delete extracted characters from the linked list.
char	*extract_str(t_node **p_head, int *p_length)
{
	char	*str;

	str = (char *)malloc(sizeof(char) * (16 + 1));
	if (!str)
	{
		delete_all(p_head);
		return (0);
	}
	strcpy16_ex03(str, p_head, p_length);
	return (str);
}

//	delete at most 16 characters from the linked list.
void	delete_16(t_node **p_head, int del_size)
{
	t_node	*cur;
	t_node	*prev;
	int		deleted;

	cur = *p_head;
	prev = 0;
	deleted = 0;
	while (deleted < del_size)
	{
		prev = cur;
		cur = cur->next;
		prev->next = 0;
		free(prev);
		deleted += 1;
	}
	*p_head = cur;
}

void	delete_all(t_node **p_head)
{
	t_node	*cur;
	t_node	*prev;

	cur = *p_head;
	prev = 0;
	while (cur)
	{
		prev = cur;
		cur = cur->next;
		prev->next = 0;
		free(prev);
	}
	*p_head = 0;
}

int	list_size(t_node *head)
{
	t_node	*cur;
	int		size;

	cur = head;
	size = 0;
	while (cur)
	{
		size += 1;
		cur = cur->next;
	}
	return (size);
}
