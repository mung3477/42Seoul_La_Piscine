/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hexdump_stdin.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 13:29:37 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/09 12:30:11 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <unistd.h>
#include "ft_string.h"
#include "ft_queue.h"

void	read_stdin(t_node **p_head, int c_flag, char buff[1]);
void	print_hexdump(t_node **p_head, int c_flag);
void	try_print_hexdump_stdin(t_node **p_head, int c_flag);

void	hexdump_stdin(int c_flag)
{
	t_node	*head;
	char	buff[1];

	head = 0;
	buff[0] = '\0';
	read_stdin(&head, c_flag, buff);
}

void	read_stdin(t_node **p_head, int c_flag, char buff[1])
{
	int	read_one_after_eof;
	int	read_at_least_once;

	read_at_least_once = 0;
	while (1)
	{
		read_one_after_eof = 0;
		while (read(0, buff, 1) > 0)
		{
			read_at_least_once = 1;
			read_one_after_eof = 1;
			if (!insert(p_head, buff[0]))
				return ;
			if (buff[0] == '\n')
				try_print_hexdump_stdin(p_head, c_flag);
		}
		try_print_hexdump_stdin(p_head, c_flag);
		if (!read_one_after_eof || buff[0] == '\n')
			break ;
	}
	if (*p_head)
		print_hexdump(p_head, c_flag);
	if (read_at_least_once)
		print_hexdump(p_head, c_flag);
}

void	try_print_hexdump_stdin(t_node **p_head, int c_flag)
{
	while (list_size(*p_head) >= 16)
		print_hexdump(p_head, c_flag);
}
