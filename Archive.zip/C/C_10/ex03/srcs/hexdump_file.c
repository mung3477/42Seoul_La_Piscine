/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hexdump_file.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 19:46:58 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/09 12:33:58 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include "ft_string.h"
#include "hexdump_info.h"

void	print_hexdump(t_node **p_head, int c_flag);
void	try_print_hexdump_file(t_node **p_head, int c_flag);
void	hexdump_file(t_hexdump_info *info, int c_flag, t_node **p_head, \
		int *p_read_at_least_once);
void	print_errmsg(t_hexdump_info *info);

void	hexdump_files(char *prog_name, char *file_names[], int c_flag, int mul)
{
	t_node			*head;
	t_hexdump_info	*info;
	int				i;
	int				read_at_least_once;

	head = 0;
	i = 1 + c_flag;
	read_at_least_once = 0;
	while (file_names[i])
	{
		info = create_hexdump_info(prog_name, file_names[i], mul);
		if (!info)
			return ;
		hexdump_file(info, c_flag, &head, &read_at_least_once);
		i += 1;
	}
	if (head)
		print_hexdump(&head, c_flag);
	if (read_at_least_once)
		print_hexdump(&head, c_flag);
	free(info);
}

void	hexdump_file(t_hexdump_info *info, int c_flag, t_node **p_head, \
		int *p_read_at_least_once)
{
	const int	fd = open(info->file_name, O_RDONLY);
	int			read_result;
	char		buff[1];

	if (fd == -1)
	{
		print_errmsg(info);
		if (info->multiple_files)
			return ;
	}
	while (1)
	{
		read_result = read(fd, buff, 1);
		if (read_result == -1)
		{
			print_errmsg(info);
			return ;
		}
		else if (read_result == 0)
			break ;
		*p_read_at_least_once = 1;
		if (!insert(p_head, buff[0]))
			return ;
	}
	try_print_hexdump_file(p_head, c_flag);
}

void	try_print_hexdump_file(t_node **p_head, int c_flag)
{
	while (list_size(*p_head) >= 16)
		print_hexdump(p_head, c_flag);
}
