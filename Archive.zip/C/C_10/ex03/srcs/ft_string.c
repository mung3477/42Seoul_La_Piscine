/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_string.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 13:31:38 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 19:44:49 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_queue.h"
#include "ft_string.h"

int	strcmp_ex03(char *str1, char *str2)
{
	int	i;

	i = 0;
	while (str1[i] && str2[i] && (str1[i] == str2[i]))
		i += 1;
	return ((int)((unsigned char)str1[i] - (unsigned char)str2[i]));
}

int	strlen_ex03(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i += 1;
	return (i);
}

void	strcpy16_ex03(char *dst, t_node **head, int *p_length)
{
	int		i;
	t_node	*cur;

	i = 0;
	cur = *head;
	while (i < 16 && cur)
	{
		dst[i] = cur->data;
		i += 1;
		cur = cur->next;
	}
	*p_length = i;
	dst[i] = '\0';
	delete_16(head, i);
}
