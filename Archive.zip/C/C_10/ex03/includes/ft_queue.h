/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_queue.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 13:37:33 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 19:46:44 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_QUEUE_H
# define FT_QUEUE_H

typedef struct s_node
{
	char			data;
	struct s_node	*next;
}				t_node;

int		insert(t_node **p_head, char data);
char	*extract_str(t_node **p_head, int *p_length);
void	delete_16(t_node **p_head, int del_size);
void	delete_all(t_node **p_head);
int		list_size(t_node *head);

#endif
