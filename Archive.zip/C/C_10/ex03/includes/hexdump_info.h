/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hexdump_info.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/08 13:39:53 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 19:46:56 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HEXDUMP_INFO_H
# define HEXDUMP_INFO_H

typedef struct s_hexdump_info
{
	char	*prog_name;
	char	*file_name;
	int		multiple_files;
}				t_hexdump_info;

t_hexdump_info	*create_hexdump_info(char *prog_name, char *file_name, int mul);

#endif
