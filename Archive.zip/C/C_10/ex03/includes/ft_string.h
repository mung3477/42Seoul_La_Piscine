/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_string.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 13:30:10 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 18:00:25 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_STRING_H
# define FT_STRING_H
# include "ft_queue.h"

int		strcmp_ex03(char *str1, char *str2);
int		strlen_ex03(char *str);
void	strcpy16_ex03(char *dst, t_node **p_head, int *p_length);

#endif
