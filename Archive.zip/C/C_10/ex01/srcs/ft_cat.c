/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cat.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/06 14:06:56 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 17:16:05 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <libgen.h>
#include <sys/errno.h>

void	ft_cat_stdin(void);
void	ft_cat_file(char *prog_name, char *pathname);
void	print_errmsg(char *prog_name, char *filename);

int	main(int argc, char *argv[])
{
	int		i;

	errno = 0;
	i = 1;
	if (argc == 1)
		ft_cat_stdin();
	else
	{
		while (argv[i])
		{
			if (argv[i][0] == '-' && argv[i][1] == '\0')
				ft_cat_stdin();
			else
				ft_cat_file(argv[0], argv[i]);
			i += 1;
		}
	}
	return (0);
}

void	ft_cat_stdin(void)
{
	unsigned char	buff[29999];
	int				read_result;
	int				idx;

	idx = 0;
	while (idx < 30000)
		buff[idx++] = '\0';
	read_result = read(0, buff, 29999);
	if (buff[0] == '\0')
		return ;
	write(1, buff, read_result);
	ft_cat_stdin();
}

void	ft_cat_file(char *prog_name, char *pathname)
{
	const int			fd = open(pathname, O_RDONLY);
	int					read_result;
	int					i;
	unsigned char		buff[29999];

	if (fd == -1)
		return (print_errmsg(basename(prog_name), pathname));
	while (1)
	{
		i = 0;
		while (i < 29999)
			buff[i++] = '\0';
		read_result = read(fd, buff, 29999);
		if (read_result == -1)
			return (print_errmsg(basename(prog_name), pathname));
		write(1, buff, read_result);
		if (read_result == 0)
			break ;
	}
}

int	strlen_ex01(const char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

void	print_errmsg(char *prog_name, char *file_name)
{
	const char	*errmsg = strerror(errno);

	write(2, prog_name, strlen_ex01(prog_name));
	write(2, ": ", 2);
	write(2, file_name, strlen_ex01(file_name));
	write(2, ": ", 2);
	write(2, errmsg, strlen_ex01(errmsg));
	write(2, "\n", 1);
}
