/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display_file.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/06 13:59:14 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/06 13:59:16 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>

int	main(int argc, char *argv[])
{
	int		fd;
	int		read_result;
	char	buff[1];

	if (argc == 1)
		return (write(1, "File name missing.\n", 19) != 0);
	if (3 <= argc)
		return (write(1, "Too many arguments.\n", 20) != 0);
	fd = open(argv[1], O_RDONLY);
	read_result = 1;
	while (1)
	{
		read_result = read(fd, buff, 1);
		if (!read_result)
			break ;
		else if (read_result == -1)
		{
			write(1, "Cannot read file.\n", 18);
			break ;
		}
		write(1, buff, 1);
	}
	close(fd);
	return (0);
}
