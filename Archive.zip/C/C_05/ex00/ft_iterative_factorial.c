/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 11:32:45 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/30 13:56:23 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	facto;

	if (nb < 0)
		return (0);
	else if (nb == 0)
		return (1);
	facto = 1;
	while (nb > 0)
		facto *= nb--;
	return (facto);
}
