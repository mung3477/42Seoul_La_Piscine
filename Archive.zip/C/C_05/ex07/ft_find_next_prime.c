/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 13:00:57 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/30 21:43:37 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	sqrt_ex07(int nb)
{
	int	sqrt_nb;

	sqrt_nb = 1;
	while ((long long)sqrt_nb * sqrt_nb <= (long long)nb)
		sqrt_nb += 1;
	return (sqrt_nb - 1);
}

int	ft_is_prime_ex07(int nb)
{
	const int	upper_bound = sqrt_ex07(nb);
	int			num;

	if (nb <= 1)
		return (0);
	num = 2;
	while (num <= upper_bound)
	{
		if (nb % num == 0)
			return (0);
		num += 1;
	}
	return (1);
}

int	ft_find_next_prime(int nb)
{
	if (nb <= 1)
		return (2);
	while (!ft_is_prime_ex07(nb))
		nb += 1;
	return (nb);
}
