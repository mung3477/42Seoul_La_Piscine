/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_prime.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 11:52:12 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/30 16:09:50 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	sqrt_ex06(int nb)
{
	int	sqrt_nb;

	sqrt_nb = 1;
	while ((long long)sqrt_nb * sqrt_nb <= (long long)nb)
		sqrt_nb += 1;
	return (sqrt_nb - 1);
}

int	ft_is_prime(int nb)
{
	const int	upper_bound = sqrt_ex06(nb);
	int			num;

	if (nb <= 1)
		return (0);
	num = 2;
	while (num <= upper_bound)
	{
		if (nb % num == 0)
			return (0);
		num += 1;
	}
	return (1);
}
