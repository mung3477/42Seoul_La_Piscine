/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 11:49:20 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/30 21:40:35 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_sqrt(int nb)
{
	int	sqrt_nb;

	sqrt_nb = 1;
	while ((long long)sqrt_nb * sqrt_nb < (long long)nb)
		sqrt_nb += 1;
	if (sqrt_nb * sqrt_nb == nb)
		return (sqrt_nb);
	else
		return (0);
}
