/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ten_queens_puzzle.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/30 13:15:05 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/30 16:10:36 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

static int	g_row_usable[10];
static int	g_col_usable[10];
static int	g_right_up_usable[19];
static int	g_right_down_usable[19];

int	usable(int row, int col)
{
	int	ret;

	ret = 1;
	ret = (ret && g_row_usable[row]);
	ret = (ret && g_col_usable[col]);
	ret = (ret && g_right_up_usable[row + col]);
	ret = (ret && g_right_down_usable[row - col + 9]);
	return (ret);
}

void	put_queen(int row, int col, char placement[11], int use)
{
	placement[col] = use * row + '0';
	g_row_usable[row] = !use;
	g_col_usable[col] = !use;
	g_right_up_usable[row + col] = !use;
	g_right_down_usable[row - col + 9] = !use;
}

int	try_put_queen(int row, int col, char placement[11])
{
	int	total;
	int	next_col;

	if (!usable(row, col))
		return (0);
	else
	{
		total = 0;
		put_queen(row, col, placement, 1);
		if (row == 9)
		{
			write(1, placement, 11);
			total += 1;
		}
		else
		{
			next_col = -1;
			while (++next_col <= 9)
				total += try_put_queen(row + 1, next_col, placement);
		}
		put_queen(row, col, placement, 0);
		return (total);
	}
}

int	ft_ten_queens_puzzle(void)
{
	char	placement[11];
	int		idx;
	int		total;

	placement[10] = '\n';
	idx = -1;
	while (++idx < 10)
	{
		g_row_usable[idx] = 1;
		g_col_usable[idx] = 1;
		g_right_up_usable[idx] = 1;
		g_right_down_usable[idx] = 1;
	}
	idx = 9;
	while (++idx < 19)
	{
		g_right_up_usable[idx] = 1;
		g_right_down_usable[idx] = 1;
	}
	total = 0;
	idx = -1;
	while (++idx <= 9)
		total += try_put_queen(0, idx, placement);
	return (total);
}
