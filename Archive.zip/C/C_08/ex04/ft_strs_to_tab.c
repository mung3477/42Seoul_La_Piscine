/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/01 13:53:16 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/03 10:38:00 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_stock_str.h"

void	no_eno_mem(struct s_stock_str *stock, int end)
{
	int	idx;

	idx = 0;
	while (idx < end)
		free(stock[idx++].copy);
	free(stock);
}

void	ft_strcpy(char *dst, char *src)
{
	int	idx;

	idx = -1;
	while (src[++idx])
		dst[idx] = src[idx];
	dst[idx] = '\0';
}

int	ft_strlen_ex04(char *str)
{
	int	idx;

	idx = 0;
	while (str[idx])
		idx += 1;
	return (idx);
}

struct s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	struct s_stock_str	*stock;
	int					idx;
	int					word_len;

	if (ac < 0)
		return (0);
	stock = (struct s_stock_str *)malloc(sizeof(struct s_stock_str) * (ac + 1));
	if (!stock)
		return (0);
	idx = -1;
	while (++idx < ac)
	{
		word_len = ft_strlen_ex04(av[idx]);
		stock[idx].size = word_len;
		stock[idx].str = av[idx];
		stock[idx].copy = (char *)malloc(sizeof(char) * (word_len + 1));
		if (!stock[idx].copy)
		{
			no_eno_mem(stock, idx);
			return (0);
		}
		ft_strcpy(stock[idx].copy, stock[idx].str);
	}
	stock[ac].str = 0;
	return (stock);
}
