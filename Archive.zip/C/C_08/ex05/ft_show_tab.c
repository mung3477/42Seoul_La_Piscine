/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_show_tab.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/01 16:32:14 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/03 10:43:44 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "ft_stock_str.h"

int	digit_count(int nb)
{
	int	digit;

	if (nb == 0)
		return (1);
	digit = 0;
	while (nb > 0)
	{
		digit += 1;
		nb /= 10;
	}
	return (digit);
}

void	ft_putnbr(int nb)
{
	char		stringfied[32];
	const int	digit = digit_count(nb);
	int			idx;

	idx = digit - 1;
	while (idx >= 0)
	{
		stringfied[idx] = nb % 10 + '0';
		nb /= 10;
		idx -= 1;
	}
	write(1, stringfied, digit);
}

int	ft_strlen_ex05(char *str)
{
	int	idx;

	idx = 0;
	while (str[idx])
		idx += 1;
	return (idx);
}

void	ft_show_tab(struct s_stock_str *par)
{
	while (par->str)
	{
		write(1, par->str, par->size);
		write(1, "\n", 1);
		ft_putnbr(par->size);
		write(1, "\n", 1);
		write(1, par->copy, ft_strlen_ex05(par->copy));
		write(1, "\n", 1);
		par += 1;
	}
}
