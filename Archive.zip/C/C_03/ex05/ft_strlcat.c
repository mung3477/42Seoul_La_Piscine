/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/25 20:10:49 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/25 22:23:12 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 *	strlcat() take the full size of the destination buffer and
 *	guarantee NUL-termination if there is room.  
 *	Note that room for the NUL should be included in dstsize.
 *
 *	strlcat() appends string src to the end of dst.  
 *	It will append at most dstsize - strlen(dst) - 1 characters.  
 *	It will then NUL-terminate, unless dstsize is 0 
 *	or the original dst string was longer than dstsize.
 *
 *	strlcat() functions return the total length of 
 *	the string they tried to create.
 *	For strlcat() that means 
 *	the initial length of dst plus the length of src.
 *  
 *  If size <= dest's original length, 
 *  returns src's length + size.
 *  If size > dest's original length, 
 *  returns strlen(src) + strlen(original dest).
 */

unsigned int	ft_strlen(char *str)
{
	unsigned int	idx;

	idx = 0;
	while (str[idx] != '\0')
		idx += 1;
	return (idx);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	dest_length;
	unsigned int	src_length;
	unsigned int	idx;

	idx = 0;
	dest_length = ft_strlen(dest);
	src_length = ft_strlen(src);
	if (size <= dest_length)
		return (src_length + size);
	while (src[idx] != '\0' && dest_length + idx < size - 1)
	{
		dest[dest_length + idx] = src[idx];
		idx += 1;
	}
	dest[dest_length + idx] = '\0';
	return (dest_length + src_length);
}
