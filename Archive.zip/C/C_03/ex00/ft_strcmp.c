/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/24 14:17:26 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/25 14:44:02 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*	
 *	The strcmp() and strncmp() functions lexicographically compare 
 *	the null-terminated strings s1 and s2.
 *	
 *	The strcmp() and strncmp() functions return an integer greater than,
 *	equal to, or less than 0, according as the string s1 is greater than,
 *	equal to, or less than the string s2.  The comparison is done using
 *	unsigned characters, so that `\200' is greater than `\0'.
 */

int	ft_strcmp(char *s1, char *s2)
{
	int	idx;
	int	ret;

	idx = 0;
	while ((s1[idx] != '\0' && s2[idx] != '\0') && (s1[idx] == s2[idx]))
		idx += 1;
	ret = (int)((unsigned char)s1[idx] - (unsigned char)s2[idx]);
	return (ret);
}
