/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/24 16:17:49 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/25 18:01:43 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 * The strcat() function append a copy of the null-terminated string s2 
 * to the end of the null-terminated string s1,then add a terminating `\0'.  
 * The string s1 must have sufficient space to hold the result.
 *
 * The strcat() function return the pointer s1.
 */
char	*ft_strcat(char *dest, char *src)
{
	int	dest_idx;
	int	src_idx;

	dest_idx = 0;
	src_idx = 0;
	while (dest[dest_idx] != '\0')
		dest_idx += 1;
	while (src[src_idx] != '\0')
		dest[dest_idx++] = src[src_idx++];
	dest[dest_idx] = '\0';
	return (dest);
}
