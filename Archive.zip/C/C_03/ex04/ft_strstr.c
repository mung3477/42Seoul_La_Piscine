/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/25 19:49:50 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/25 22:22:05 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 *	The strstr() function locates the first occurrence of 
 *	the null-terminated string needle 
 *	in the null-terminated string haystack.
 *
 *	If needle is an empty string, haystack is returned; 
 *	if needle occurs nowhere in haystack, NULL is returned; 
 *	otherwise a pointer to the first character 
 *	of the first occurrence of needle is returned.
 */

char	*ft_strstr(char *str, char *to_find)
{
	int	idx;
	int	check;

	if (to_find[0] == '\0')
		return (str);
	idx = 0;
	while (str[idx] != '\0')
	{
		check = 0;
		while (to_find[check] && str[idx + check] == to_find[check])
			check += 1;
		if (to_find[check] == '\0')
			return (str + idx);
		idx += 1;
	}
	return (0);
}
