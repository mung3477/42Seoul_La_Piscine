/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/25 18:05:08 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/25 18:12:49 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 *	The strncat() function append a copy of the null-terminated string s2 
 *	to the end of the null-terminated string s1, 
 *	then add a terminating `\0'.  
 *	The string s1 must have sufficient space to hold the result.
 *
 *	The strncat() function appends not more than n characters from s2, 
 *	and then adds a terminating `\0'.
 *
 *	Strncat() function return the pointer s1.
 *
 *	If nb is 0, concats nothing to dest.
 */
char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	dest_idx;
	unsigned int	src_idx;

	dest_idx = 0;
	while (dest[dest_idx] != '\0')
		dest_idx += 1;
	src_idx = 0;
	while ((src_idx < nb) && (src[src_idx] != '\0'))
		dest[dest_idx++] = src[src_idx++];
	dest[dest_idx] = '\0';
	return (dest);
}
