#include <stdio.h>
#include <string.h>

#include "ex00/ft_strcmp.c"
#include "ex01/ft_strncmp.c"
#include "ex02/ft_strcat.c"
#include "ex03/ft_strncat.c"
#include "ex04/ft_strstr.c"
#include "ex05/ft_strlcat.c"

/* 
	Written by wjoung, 2022 7-2 La piscine.
	Compares handmade-function's action with the original one.
*/
int main(void)
{
	{	
		printf("====ex00====\n");
		char c1[6] = "ABCDE", c2[6] = "ABCDD";
		printf("%s vs %s: %d | std: %d \n", c1, c2, ft_strcmp(c1, c2), strcmp(c1, c2));	
		char c3[2] = "\200", c4[2] = "\0";
		printf("%s vs %s : %d | std: %d \n", c3, c4, ft_strcmp(c3, c4), strcmp(c3, c4));
	}
	{
		printf("\n====ex01====\n");
		char c1[10] = "ABCDEFGHI", c2[10] = "ABCDPQRST";
		char c5[2] = "\200", c6[2] = "\0";
		printf("%s vs %s : %d | std: %d\n", c5, c6, ft_strncmp(c5, c6, 1), strncmp(c5, c6, 1));
		printf("(a < b) %s vs %s : %d | std: %d\n", c1, c2, ft_strncmp(c1, c2, 5), strncmp(c1, c2, 5));
		printf("(a > b) %s vs %s : %d | std: %d\n", c2, c1, ft_strncmp(c2, c1, 5), strncmp(c2, c1, 5));
		printf("(a == b) %s vs %s : %d | std: %d\n", c2, c1, ft_strncmp(c2, c1, 4), strncmp(c2, c1, 4));
		printf("(size == 0) %s vs %s : %d | std: %d\n", c1, c2, ft_strncmp(c1, c2, 0), strncmp(c1, c2, 0));
		
		char c3[10] = "ABC", c4[10] = "ABC";
		printf("(size > src, dst) %s vs %s : %d | std: %d\n", c3, c4, ft_strncmp(c3, c4, 20), strncmp(c3, c4, 20));
	}
	{
		printf("====ex02====\n");
		char c1[30] = "HELLO", c2[6] = "joung";
		char c3[30] = "HELLO", c4[6] = "joung";
		printf("mine: %s\norig: %s\n", ft_strcat(c1, c2), strcat(c3, c4));
	}
	{
		printf("====ex03====\n");
		char c1[30] = "HELLO", c2[6] = "joung";
		char c3[30] = "HELLO", c4[6] = "joung";
		printf("(size == 0) mine: %s\torig: %s\n", ft_strncat(c1, c2, 0), strncat(c3, c4, 0));
		printf("(size <= src) mine: %s\torig: %s\n", ft_strncat(c1, c2, 3), strncat(c3, c4, 3));
		printf("(size > src) mine: %s\torig: %s\n", ft_strncat(c1, c2, 26), strncat(c3, c4, 26));
		
	}
	{
		printf("====ex04====\n");
		char c1[30] = "abcHELLHHHHHHELLO", c2[6] = "HELLO", c3[4] = "ABC";
		printf("(Has) mine: %p\torig: %p\n", ft_strstr(c1, c2), strstr(c1, c2));
		printf("(None) mine: %p\torig: %p\n", ft_strstr(c1, c3), strstr(c1, c3));
		printf("(needle length 0) mine: %p\torig: %p\n", ft_strstr(c1, ""), strstr(c1, ""));
	}
	{
		printf("====ex05====\n");
		printf("(size 0)\n");
		char dst_me[30] = "abc", dst_orig[30] = "abc",  c2[6] = "HELLO";
		printf("mine: %u\torig: %lu\n", ft_strlcat(dst_me, c2, 0), strlcat(dst_orig, c2, 0));
		printf("mine: %s\torig: %s\n", dst_me, dst_orig);
		printf("(size < dest orig len)\n");
		char dst_me2[30] = "abc", dst_orig2[30] = "abc";
		printf("mine: %u\torig: %lu\n", ft_strlcat(dst_me2, c2, 2), strlcat(dst_orig2, c2, 2));
		printf("mine: %s\torig: %s\n", dst_me2, dst_orig2);
		printf("(size = dest orig len + 1)\n");
		char dst_me3[30] = "abc", dst_orig3[30] = "abc";
		printf("mine: %u\torig: %lu\n", ft_strlcat(dst_me3, c2, 4), strlcat(dst_orig3, c2, 4));
		printf("mine: %s\torig: %s\n", dst_me3, dst_orig3);
		printf("(size < dest len)\n");
		char dst_me4[30] = "abc", dst_orig4[30] = "abc";
		printf("mine: %u\torig: %lu\n", ft_strlcat(dst_me4, c2, 6), strlcat(dst_orig4, c2, 6));
		printf("mine: %s\torig: %s\n", dst_me4, dst_orig4);
		printf("(size < dest len + src len)\n");
		char dst_me5[30] = "abc", dst_orig5[30] = "abc";
		printf("mine: %u\torig: %lu\n", ft_strlcat(dst_me5, c2, 10), strlcat(dst_orig5, c2, 10));
		printf("mine: %s\torig: %s\n", dst_me5, dst_orig5);
	}

	return 0;
}
