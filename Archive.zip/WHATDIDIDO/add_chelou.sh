#!/bin/sh
# Function to decrypt given string to 5 base integer
# 1st parameter($1) is given string, and 2nd parameter($2) is base string
function decryptSymbolBase () {
	decrypted=$(echo $1 | sed "s/\'/0/g" |  sed 's/\\/1/g' | sed 's/\"/2/g' | sed 's/\?/3/g' | sed 's/\!/4/g')
	echo "$decrypted"
}

function decryptCharBase () {
	decrypted=$(echo $1 | sed 's/m/0/g; s/r/1/g; s/d/2/g; s/o/3/g; s/c/4/g')
	echo "$decrypted"
}

# Function to change base($2) expressed $1 to 10 base integer
function changeToInt() {
	original=$(($1))
	echo "$original"
	changed=0
	expoBase=1
	while [ $original -gt 0 ]
	do
		changed=$(( $changed + $original % 10 * $expoBase | bc ))
		expoBase=$(( $expoBase * $2 | bc))
		original=$(( $original / 10 | bc))
		echo "$changed"
	done
	echo "$changed"
}


decryptedNBR1=$(decryptSymbolBase $FT_NBR1)
decryptedNBR2=$(decryptCharBase $FT_NBR2)
echo "$decryptedNBR2"
# NBR1=$(changeToInt $decryptedNBR1 5)
NBR2=$(changeToInt $decryptedNBR2 5)
# echo "$NBR1"
echo "$NBR2"
# sum=$(( $NBR1 + $NBR2 | bc ))
# echo "obase=13; $sum" | bc 

