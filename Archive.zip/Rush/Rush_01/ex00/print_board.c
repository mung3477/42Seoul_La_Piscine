/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_board.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/29 12:06:39 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/29 18:01:23 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	print_board(int n, int **board)
{
	int		idx;
	int		jdx;
	int		cur_num;
	char	cur_char;

	idx = 0;
	while (++idx <= n)
	{
		jdx = 0;
		while (++jdx <= n)
		{
			cur_num = board[idx][jdx];
			if (cur_num < 0)
				cur_num *= -1;
			cur_char = cur_num + '0';
			write(1, &cur_char, 1);
			if (jdx != n)
				write(1, " ", 1);
		}
		write(1, "\n", 1);
	}
	return (1);
}
