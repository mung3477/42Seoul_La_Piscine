/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   alloc_free.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/29 16:41:56 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/29 16:42:01 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	**board_alloc(int n)
{
	int	idx;
	int	jdx;
	int	**board;

	idx = -1;
	board = (int **)malloc(sizeof(int *) * (n + 2));
	while (++idx < n + 2)
	{
		board[idx] = (int *)malloc(sizeof(int) * (n + 2));
		jdx = -1;
		while (++jdx < n + 2)
			board[idx][jdx] = 0;
	}
	return (board);
}

void	board_free(int n, int **board)
{
	int	idx;

	idx = -1;
	while (++idx < n + 2)
		free(board[idx]);
	free(board);
}

int	**usable_alloc(int n)
{
	int	idx;
	int	jdx;
	int	**usable;

	idx = -1;
	usable = (int **)malloc(sizeof(int *) * (n + 1));
	while (++idx <= n)
	{
		usable[idx] = (int *)malloc(sizeof(int) * (n + 1));
		jdx = -1;
		while (++jdx <= n)
			usable[idx][jdx] = 1;
	}
	return (usable);
}
