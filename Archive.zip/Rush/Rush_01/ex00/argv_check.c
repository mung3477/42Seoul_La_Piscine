/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   argv_check.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jihylim <jihylim@student.42seoul.k>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/28 20:20:25 by jihylim           #+#    #+#             */
/*   Updated: 2022/05/29 13:50:32 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	check(int n)
{
	n = (n + 1) / 2;
	if (n % 4 == 0 && n >= 4 && n <= 36)
		return (n / 4);
	return (0);
}

int	*argv_check(char *av, int *count)
{
	int	i;
	int	j;
	int	*arr;
	int	n;

	n = check(ft_strlen(av));
	arr = (int *)malloc(sizeof(int) * 4 * n);
	if (!n | !arr)
		return (0);
	i = -1;
	j = 0;
	while (av[++i])
	{
		if (i % 2 == 0)
		{
			if (av[i] >= '1' && av[i] <= (n + '0'))
				arr[j++] = av[i] - '0';
			else
				return (0);
		}
		else if (av[i] != ' ')
			return (0);
	}
	*count = n;
	return (arr);
}
