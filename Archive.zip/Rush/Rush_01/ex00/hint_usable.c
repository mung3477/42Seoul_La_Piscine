/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hint_usable.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: junyojeo <junyojeo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/29 10:55:11 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/29 23:31:08 by junyojeo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

static int	g_n;

int	rowleft_hint_usable(int row, int end, int **board)
{
	int	idx;
	int	biggest;
	int	can_see;
	int	cur;

	idx = 0;
	biggest = 0;
	can_see = 0;
	while (++idx <= g_n && board[row][idx] != 0)
	{
		cur = board[row][idx];
		if (cur < 0)
			cur *= -1;
		if (biggest < cur)
		{
			can_see += 1;
			biggest = cur;
		}
	}
	if (end)
		return (board[row][0] == g_n - biggest + can_see);
	return (board[row][0] <= g_n - biggest + can_see);
}

int	colup_hint_usable(int col, int end, int **board)
{
	int	idx;
	int	biggest;
	int	can_see;
	int	cur;

	idx = 0;
	biggest = 0;
	can_see = 0;
	while (++idx <= g_n && board[idx][col] != 0)
	{
		cur = board[idx][col];
		if (cur < 0)
			cur *= -1;
		if (biggest < cur)
		{
			can_see += 1;
			biggest = cur;
		}
	}
	if (end)
		return (board[0][col] == g_n - biggest + can_see);
	return (board[0][col] <= g_n - biggest + can_see);
}

int	rowright_hint_usable(int row, int **board)
{
	int	idx;
	int	biggest;
	int	can_see;
	int	cur;

	idx = g_n + 1;
	biggest = 0;
	can_see = 0;
	while (1 <= --idx)
	{
		cur = board[row][idx];
		if (cur < 0)
			cur *= -1;
		if (biggest < cur)
		{
			can_see += 1;
			biggest = cur;
		}
	}
	return (board[row][g_n + 1] == can_see);
}

int	coldown_hint_usable(int col, int **board)
{
	int	idx;
	int	biggest;
	int	can_see;
	int	cur;

	idx = g_n + 1;
	biggest = 0;
	can_see = 0;
	while (1 <= --idx)
	{
		cur = board[idx][col];
		if (cur < 0)
			cur *= -1;
		if (biggest < cur)
		{
			can_see += 1;
			biggest = cur;
		}
	}
	return (board[g_n + 1][col] == can_see);
}

int	hint_usable(const int row_col[2], int num, int n, int **board)
{
	const int	row = row_col[0];
	const int	col = row_col[1];
	int			ret;

	g_n = n;
	ret = 1;
	if (board[row][col] >= 0)
		board[row][col] = num;
	ret = (ret && rowleft_hint_usable(row, col == n, board));
	ret = (ret && colup_hint_usable(col, row == n, board));
	if (col == n)
		ret = (ret && rowright_hint_usable(row, board));
	if (row == n)
		ret = (ret && coldown_hint_usable(col, board));
	if (board[row][col] >= 0)
		board[row][col] = 0;
	return (ret);
}
