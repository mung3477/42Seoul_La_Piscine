/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: junyojeo <junyojeo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/28 15:27:42 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/29 23:38:34 by junyojeo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>

int	*argv_check(char *argv, int *count);
int	solve(int *hint, int n);

int	main(int argc, char *argv[])
{
	int	*hint;
	int	n;
	int	result;

	n = 0;
	hint = 0;
	if (argc == 2)
		hint = argv_check(argv[1], &n);
	if (!n)
		write(1, "Error\n", 6);
	else
	{
		result = solve(hint, n);
		if (!result)
			write(1, "Error\n", 6);
	}
	if (n)
		free(hint);
	return (0);
}
