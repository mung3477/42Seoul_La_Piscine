/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   preprocess.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/29 16:34:43 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/29 17:16:59 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	use_hint_both(int N, int **board);

void	use_hint_colup(int N, int **board)
{
	int	col;
	int	row;

	col = 0;
	while (++col <= N)
	{
		row = 0;
		if (board[0][col] == 1)
			board[1][col] = N * -1;
		else if (board[0][col] == N)
			while (++row <= N)
				board[row][col] = -1 * row;
	}
}

void	use_hint_coldown(int N, int **board)
{
	int	col;
	int	row;

	col = 0;
	while (++col <= N)
	{
		row = N + 1;
		if (board[N + 1][col] == 1)
			board[N][col] = N * -1;
		else if (board[N + 1][col] == N)
			while (1 <= --row)
				board[row][col] = -1 * (N - row + 1);
	}
}

void	use_hint_rowleft(int N, int **board)
{
	int	col;
	int	row;

	row = 0;
	while (++row <= N)
	{
		col = 0;
		if (board[row][0] == 1)
			board[row][1] = N * -1;
		else if (board[row][0] == N)
			while (++col <= N)
				board[row][col] = -1 * col;
	}
}

void	use_hint_rowright(int N, int **board)
{
	int	col;
	int	row;

	row = 0;
	while (++row <= N)
	{
		col = N + 1;
		if (board[row][N + 1] == 1)
			board[row][N] = N * -1;
		else if (board[row][N + 1] == N)
			while (1 <= --col)
				board[row][col] = -1 * (N - col + 1);
	}
}

void	preprocess(int n, int **board)
{
	use_hint_colup(n, board);
	use_hint_coldown(n, board);
	use_hint_rowleft(n, board);
	use_hint_rowright(n, board);
	use_hint_both(n, board);
}
