/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   put_hint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: junyojeo <junyojeo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/28 20:18:01 by junyojeo          #+#    #+#             */
/*   Updated: 2022/05/29 17:24:30 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	preprocess(int n, int **board);

/*
 *	board (N + 2) * (N + 2) * (N + 1)
 *	row / col : hints on 0, N + 1, 1 ~ N is used board
 *	Input: hint (N^2), board size N
 */
void	put_hint(int *hint, int n, int **board)
{
	int	idx;
	int	jdx;
	int	kdx;

	idx = 0;
	kdx = 0;
	while (idx <= n + 1)
	{
		jdx = 0;
		while (++jdx <= n)
			board[idx][jdx] = hint[kdx * n + jdx - 1];
		kdx++;
		idx += n + 1;
	}
	idx = 0;
	while (idx <= n + 1)
	{
		jdx = 0;
		while (++jdx <= n)
			board[jdx][idx] = hint[kdx * n + jdx - 1];
		kdx++;
		idx += n + 1;
	}
	preprocess(n, board);
}
