/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   use_hint_both.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/29 18:49:07 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/29 18:49:10 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	use_hint_both_col(int N, int **board)
{
	int	col;

	col = 0;
	while (++col <= N)
	{
		if (board[0][col] + board[N + 1][col] == N + 1)
			board[board[0][col]][col] = -1 * N;
	}
}

void	use_hint_both_row(int N, int **board)
{
	int	row;

	row = 0;
	while (++row <= N)
	{
		if (board[row][0] + board[row][N + 1] == N + 1)
			board[row][board[row][0]] = -1 * N;
	}
}

void	use_hint_both(int N, int **board)
{
	use_hint_both_row(N, board);
	use_hint_both_col(N, board);
}
