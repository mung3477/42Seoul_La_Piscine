/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: junyojeo <junyojeo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/29 10:41:15 by wjoung            #+#    #+#             */
/*   Updated: 2022/05/29 18:51:23 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

static int	g_n;
static int	**g_row_usable;
static int	**g_col_usable;

int		**board_alloc(int n);
void	board_free(int n, int **board);
int		**usable_alloc(int n);
void	put_hint(int *hint, int n, int **board);
int		hint_usable(const int row_col[2], int num, int n, int **board);
int		print_board(int n, int **board);

int	preprocess_usables(int N, int **board)
{
	int	row;
	int	col;
	int	cur;

	row = 0;
	while (++row <= N)
	{
		col = 0;
		while (++col <= N)
		{
			cur = board[row][col];
			if (cur < 0)
			{
				cur *= -1;
				if (!g_row_usable[row][cur] || !g_col_usable[col][cur])
					return (0);
				else
				{
					g_row_usable[row][cur] = 0;
					g_col_usable[col][cur] = 0;
				}
			}
		}
	}
	return (1);
}

/*
 *	if board value is fixed, don't do anything.
 *
 *	if use is 1, put num to board[row][col][0].
 *		then manipulate related row and col's availables.
 *
 *	if use is 0, delete num in board[row][col][0].
 *		then manipulate related row and col's availables.
 */
void	manipulate(const int *row_col, int num, int use, int **board)
{
	const int	row = row_col[0];
	const int	col = row_col[1];

	if (board[row][col] >= 0)
	{
		board[row][col] = use * num;
		g_row_usable[row][num] = !use;
		g_col_usable[col][num] = !use;
	}
}

int	usable(const int row_col[2], int num, int **board)
{
	const int	row = row_col[0];
	const int	col = row_col[1];
	const int	no_duplicate = g_row_usable[row][num] && g_col_usable[col][num];
	const int	cur = board[row][col];

	if (cur < 0)
		return (cur * -1 == num && hint_usable(row_col, num, g_n, board));
	else
		return (no_duplicate && hint_usable(row_col, num, g_n, board));
}

int	put(int row, int col, int num, int **board)
{
	const int	row_col[2] = {row, col};
	int			result;
	int			next_num;
	int			next_col;

	if (row == g_n + 1)
		return (print_board(g_n, board));
	if (usable(row_col, num, board))
	{
		manipulate(row_col, num, 1, board);
		next_num = 0;
		result = 0;
		next_col = col + 1;
		while (++next_num <= g_n && !result)
		{
			if (next_col != g_n + 1)
				result = put(row, next_col, next_num, board);
			else
				result = put(row + 1, 1, next_num, board);
		}
		if (!result)
			manipulate(row_col, num, 0, board);
		return (result);
	}
	return (0);
}

/*
 *	board (N + 2) * (N + 2) * (N + 1)
 *	row / col : 0, N + 1번째 줄에 힌트, 1 ~ N번이 진짜 보드
 *	z축:		0번에 보드 입력값. 전처리 과정에서 고정되면 음수
 *				1 ~ N번까지 그 수를 그 자리에 쓸 수 있는지( = 1) 없는지( = 0) 
 */
int	solve(int *hint, int n)
{
	int	result;
	int	num;
	int	**board;

	g_n = n;
	board = board_alloc(n);
	g_row_usable = usable_alloc(n);
	g_col_usable = usable_alloc(n);
	put_hint(hint, n, board);
	if (!(preprocess_usables(n, board)))
		return (0);
	num = 0;
	result = 0;
	while (++num <= n && !result)
		result = put(1, 1, num, board);
	board_free(n, board);
	num = -1;
	while (++num <= n)
	{
		free(g_row_usable[num]);
		free(g_col_usable[num]);
	}
	free(g_row_usable);
	free(g_col_usable);
	return (result);
}
