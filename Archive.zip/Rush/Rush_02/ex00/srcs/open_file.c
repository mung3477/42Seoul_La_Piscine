/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   open_file.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 20:17:09 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/05 22:47:40 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <unistd.h>

int	open_file(int argc, char *argv[])
{
	int	fd;

	fd = -2;
	if (3 < argc)
		write(1, "Too many arguments\n", 19);
	else if (argc == 1)
		write(1, "Program needs more arguments\n", 29);
	else if (argc == 2)
		fd = open("dictionary/numbers.dict", O_RDONLY);
	else if (argc == 3)
		fd = open(argv[1], O_RDONLY);
	return (fd);
}
