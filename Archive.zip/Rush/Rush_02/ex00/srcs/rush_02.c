/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush_02.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 13:52:10 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/05 22:21:42 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	process_lines(char ***dict_val, int fd, int *dict_err, int *mem_err);
void	check_dictionary(char ***dict_val, int *dict_err);
void	conv_input(char ***dict_val, unsigned int input);
char	***alloc_dict(int *mem_err);
void	free_dict(char ***dict);

void	print_dict(char ***dict)
{
	int			idx;
	int			jdx;
	const int	dict_in_size[5] = {10, 10, 10, 1, 13};

	idx = -1;
	while (dict[++idx])
	{
		jdx = -1;
		while (++jdx < dict_in_size[idx])
			if (dict[idx][jdx] && !(idx == 4 && 4 <= jdx))
			{
				printf("(%d, %d): %s\n", idx, jdx, dict[idx][jdx]);
			}
	}
}

void	rush_02(int fd, unsigned int input, int *mem_err)
{
	char	***dict_val;
	int		dict_err;

	dict_err = 0;
	dict_val = alloc_dict(mem_err);
	if (*mem_err)
		return ;
	process_lines(dict_val, fd, &dict_err, mem_err);
	if (*mem_err)
		return ;
	check_dictionary(dict_val, &dict_err);
	if (dict_err)
	{
		write(1, "Dict Error\n", 11);
		free_dict(dict_val);
		return ;
	}
	conv_input(dict_val, input);
	print_dict(dict_val);
	free_dict(dict_val);
}
