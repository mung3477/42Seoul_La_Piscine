/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyeokim2 <hyeokim2@student.42seoul.kr      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 20:32:34 by hyeokim2          #+#    #+#             */
/*   Updated: 2022/06/05 21:36:43 by hyeokim2         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_idx(char *block)
{
	int	i;

	i = 0;
	while ((block[i] >= 9 && block[i] <= 13) || block[i] == 32)
		i++;
	if (block[i] == '-' || block[i] == '+')
	{
		if (block[i] == '-')
			return (-1);
		i++;
	}
	if (block[i] == '-' || block[i] == '+')
		return (-1);
	return (i);
}

int	check_valid(char *block, int *dict_err)
{
	int	i;
	int	cnt;

	cnt = 0;
	i = check_idx(block);
	if (block[i] == '-' || block[i] == '+')
		return (-1);
	while (block[i] >= '0' && block[i] <= '9')
	{
		i++;
		cnt++;
	}
	while (block[i] != ':')
		i++;
	if (block[i] == '\0')
	{
		*dict_err = 1;
		return (-1);
	}
	return (cnt);
}

void	check_overflow(char *block, char ***dict_val)
{
	int	i;
	int	cnt;

	i = 0;
	while ((block[i] >= 9 && block[i] <= 13) || block[i] == 32)
		i++;
	if (block[i] == '-' || block[i] == '+')
		i++;
	cnt = 0;
	if (block[i] != '1')
		return ;
	else
		i++;
	while ((!(block[i] >= 9 && block[i] <= 13)) && (block[i] != 32) \
			&& (block[i] != ':'))
	{
		if (block[i] == '0' && !(block[i + 1] >= '1' && block[i + 1] <= '9'))
		cnt++;
		else
			return ;
		i++;
	}
	if (cnt % 3 == 0)
		dict_val[4][cnt / 3] = "1";
}

int	check_dict(long long num)
{
	if (num < 0)
		return (0);
	else if (num >= 0 && num <= 19)
		return (1);
	else if (num % 10 == 0 && num <= 100 && num >= 20)
		return (1);
	else if (num == 1000 || num == 1000000 || num == 1000000000)
		return (1);
	else
		return (0);
}

long long	ft_atoi(char *block, char ***dict_val, int *dict_err)
{
	int			i;
	long long	num;

	num = 0;
	if (check_valid(block, dict_err) > 10)
	{
		check_overflow(block, dict_val);
		return (-1);
	}
	if (check_valid(block, dict_err) == -1)
		return (-1);
	i = check_idx(block);
	while ((!(block[i] >= 9 && block[i] <= 13)) && (block[i] != 32) \
			&& (block[i] != ':'))
	{
		if (block[i] >= '0' && block[i] <= '9')
			num = num * 10 + (block[i] - '0');
		else
			break ;
		i++;
	}
	if (check_dict(num) == 0)
		return (-1);
	return (num);
}
