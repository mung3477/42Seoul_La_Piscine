/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   alloc_free_dict.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/04 15:52:20 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/05 17:07:28 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

void	alloc_dict_inside(char ***dict, int *mem_err)
{
	int			idx;
	int			jdx;
	const int	dict_in_size[5] = {10, 10, 10, 1, 13};

	idx = -1;
	while (++idx < 5)
	{
		jdx = 0;
		dict[idx] = (char **)malloc(sizeof(char *) * dict_in_size[idx]);
		if (!dict[idx])
		{
			*mem_err = 1;
			while (jdx < idx)
				free(dict[jdx++]);
			break ;
		}
		while (jdx < dict_in_size[idx])
			dict[idx][jdx++] = 0;
	}
}

char	***alloc_dict(int *mem_err)
{
	char	***dict;

	dict = (char ***)malloc(sizeof(char **) * (5 + 1));
	if (!dict)
	{
		*mem_err = 1;
		return (0);
	}
	dict[5] = 0;
	alloc_dict_inside(dict, mem_err);
	if (*mem_err)
	{
		free(dict);
		dict = 0;
	}
	return (dict);
}
#include <stdio.h>
void	free_dict(char ***dict)
{
	int			idx;
	int			jdx;
	const int	dict_in_size[5] = {10, 10, 10, 1, 13};

	idx = -1;
	while (dict[++idx])
	{
		jdx = -1;
		while (++jdx < dict_in_size[idx])
			if (dict[idx][jdx] && !(idx == 4 && 4 <= jdx))
			{
				free(dict[idx][jdx]);
			}
		free(dict[idx]);
	}
	free(dict);
}

void	free_during_put_val(char ***dict)
{
	int			idx;
	int			jdx;
	const int	dict_in_size[5] = {10, 10, 10, 1, 13};

	idx = -1;
	while (dict[++idx])
	{
		jdx = -1;
		while (++jdx < dict_in_size[idx])
			if (dict[idx][jdx] && !(idx == 4 && 4 <= jdx))
				free(dict[idx][jdx]);
		free(dict[idx]);
	}
	free(dict);
}
