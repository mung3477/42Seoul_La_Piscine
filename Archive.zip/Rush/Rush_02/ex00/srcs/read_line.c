/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_line.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 13:52:06 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/05 22:22:06 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include "../includes/ft_queue.h"

char	*read_line(int fd, int *mem_err, int *dict_err)
{
	t_node	*head;
	char	buff[1];

	head = 0;
	while (read(fd, buff, 1) > 0)
	{
		if (buff[0] == '\n')
			return (extract_str(head));
		if (!insert(buff[0], &head))
		{
			*mem_err = 1;
			return (0);
		}
	}
	if (head)
		*dict_err = 1;
	free(extract_str(head));
	return (0);
}
