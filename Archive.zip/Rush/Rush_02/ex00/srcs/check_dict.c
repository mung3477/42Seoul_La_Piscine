/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_dict.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 13:51:27 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/05 17:10:38 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_dict_in(char **dict_inside, int idx)
{
	int	jdx;
	int	valid;

	valid = 1;
	if (idx == 0 || idx == 1)
	{
		jdx = -1;
		while (++jdx <= 9)
			valid = (valid && dict_inside[jdx]);
	}
	else if (idx == 2)
	{
		jdx = 1;
		while (++jdx <= 9)
			valid = (valid && dict_inside[jdx]);
	}
	else if (idx == 4)
	{
		jdx = 0;
		while (++jdx <= 12)
			valid = (valid && dict_inside[jdx]);
	}
	else
		valid = (valid && dict_inside[0]);
	return (valid);
}

void	check_dictionary(char ***dict_val, int *dict_err)
{
	int	idx;
	int	valid;

	if (*dict_err)
		return ;
	idx = 0;
	valid = 1;
	while (dict_val[idx] && valid)
	{
		valid = check_dict_in(dict_val[idx], idx);
		idx += 1;
	}
	*dict_err = !valid;
}
