/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/04 15:32:26 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/05 20:29:37 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void			rush_02(int fd, unsigned int value, int *mem_err);
int				open_file(int argc, char *argv[]);
int				is_space(char c);
unsigned int	val_atoi(char *str, int *arg_err);

int	main(int argc, char *argv[])
{
	const int		fd = open_file(argc, argv);
	unsigned int	value;
	int				mem_err;
	int				arg_err;

	mem_err = 0;
	arg_err = 0;
	if (fd == -1)
		return (write(1, "Error opening the dictionary file\n", 34) != -1);
	else if (fd == -2)
		return (0);
	value = val_atoi(argv[1 + (argc == 3)], &arg_err);
	if (arg_err)
	{
		close(fd);
		return (write(1, "Error\n", 6) != -1);
	}
	rush_02(fd, value, &mem_err);
	if (mem_err)
	{
		close(fd);
		return (write(1, "Error allocating or freeing memories\n", 37) != -1);
	}
	close(fd);
	return (0);
}
