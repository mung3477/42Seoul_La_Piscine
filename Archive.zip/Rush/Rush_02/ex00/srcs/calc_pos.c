/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   calc_pos.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 19:46:31 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/05 20:13:39 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	calc_pos_0(int key)
{
	if (0 <= key && key <= 9)
		return (0);
	else if (10 <= key && key <= 19)
		return (1);
	else if (20 <= key && key <= 90)
		return (2);
	else if (key == 100)
		return (3);
	else
		return (4);
}

int	calc_pos_1(int key)
{
	int	pos_1;

	if (0 <= key && key <= 9)
		return (key);
	else if (10 <= key && key <= 19)
		return (key % 10);
	else if (20 <= key && key <= 90)
		return (key / 10);
	else if (key == 100)
		return (0);
	else
	{
		pos_1 = -1;
		while (key)
		{
			pos_1 += 1;
			key /= 1000;
		}
		return (pos_1);
	}
}
