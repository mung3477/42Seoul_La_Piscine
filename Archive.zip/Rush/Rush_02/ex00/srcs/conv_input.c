/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   conv_input.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: woojeong <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/04 15:39:21 by woojeong          #+#    #+#             */
/*   Updated: 2022/06/05 15:38:55 by woojeong         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_hundred(char ***dict_val, unsigned int hundred);
void	putstr(char *str);

void	conv_input(char ***dict_val, unsigned int input)
{
	int	exp;
	int	p;

	if (input == 0)
		putstr(dict_val[0][0]);
	exp = 1000000000;
	p = 3;
	while (exp >= 1000)
	{
		if (input / exp > 0)
		{
			print_hundred(dict_val, input / exp);
			write(1, " ", 1);
			putstr(dict_val[4][p]);
			if (input - ((input / exp) * exp) != 0)
				write(1, " ", 1);
		}
		input = input - ((input / exp) * exp);
		exp = exp / 1000;
		p--;
	}
	print_hundred(dict_val, input);
	write(1, "\n", 1);
}

void	print_hundred(char ***dict_val, unsigned int hundred)
{
	if (hundred / 100 != 0)
	{
		putstr(dict_val[0][hundred / 100]);
		write(1, " ", 1);
		putstr(dict_val[3][0]);
		if (hundred - ((hundred / 100) * 100) != 0)
			write(1, " ", 1);
	}
	hundred = hundred - ((hundred / 100) * 100);
	if (hundred >= 10 && hundred <= 19)
	{
		putstr(dict_val[1][hundred - 10]);
		return ;
	}
	else if (hundred >= 20)
	{
		putstr(dict_val[2][hundred / 10]);
		if (hundred - ((hundred / 10) * 10) != 0)
			write(1, " ", 1);
	}
	hundred = hundred - ((hundred / 10) * 10);
	if (hundred != 0)
		putstr(dict_val[0][hundred]);
}

void	putstr(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		write(1, &str[i], 1);
		i++;
	}
}
