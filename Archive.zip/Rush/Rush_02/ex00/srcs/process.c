/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   process.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 13:52:00 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/05 22:34:41 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int			is_printable(char c);
int			is_space(char c);
int			calc_pos_0(int key);
int			calc_pos_1(int key);
void		free_during_put_val(char ***dict);
long long	ft_atoi(char *block, char ***dict_val, int *dict_err);

/*
    if memory was not enough, return 0.
    size contains a position for \0.
*/
int	ft_strdup(char **dst, char *src, int size)
{
	int	idx;

	idx = 0;
	*dst = (char *)malloc(sizeof(char) * size);
	if (!(*dst))
		return (0);
	while (idx < size - 1)
	{
		(*dst)[idx] = src[idx];
		idx += 1;
	}
	(*dst)[idx] = '\0';
	return (1);
}

// returns 1 if success, 0 if fail (memory is not enough)
int	put_value(int key, char *line, char ***dict_val, int *dict_err)
{
	int			idx;
	int			end;
	const int	pos_0 = calc_pos_0(key);
	const int	pos_1 = calc_pos_1(key);

	idx = 0;
	while (line[idx] != ':')
		idx += 1;
	idx += 1;
	while (is_space(line[idx]))
		idx += 1;
	end = idx;
	while (line[end] && is_printable(line[end]))
		end += 1;
	if (end == idx || (end != idx && line[end] && !is_printable(line[end])))
	{
		*dict_err = 1;
		return (0);
	}
	if (key == -1)
		return (0);
	return (ft_strdup(&dict_val[pos_0][pos_1], &line[idx], end - idx + 1));
}

int	check_valid_line(char *line, int *is_key_neg)
{
	int	idx;
	int	ret;
	int	sign;

	idx = 0;
	ret = 0;
	sign = 1;
	while (is_space(line[idx]))
		idx += 1;
	if (line[idx] == '+' || line[idx] == '-')
	{
		if (line[idx] == '-')
			sign *= -1;
		idx += 1;
	}
	while ('0' <= line[idx] && line[idx] <= '9')
	{
		ret = ret * 10 + line[idx] - '0';
		idx += 1;
	}
	while (line[idx] && line[idx] != ':')
		idx += 1;
	*is_key_neg = (sign == -1 && ret != 0);
	return (line[idx] == ':');
}
#include <stdio.h>
void	process(char *line, char ***dict_val, int *dict_err, int *mem_err)
{
	long long	key;
	int			result;
	int			is_key_neg;

	if (*mem_err)
		return ;
	if ((line[0] == ':') || !check_valid_line(line, &is_key_neg))
	{
		*dict_err = 1;
		return ;
	}
	if (is_key_neg)
		key = -1;
	else
	{
		key = ft_atoi(line, dict_val, dict_err);
		printf("this line: %s\nkey: %lld\n", line, key);
	}
	result = put_value(key, line, dict_val, dict_err);
	if (dict_err)
		return ;
	else if (result)
	{
			printf("result == %d\n", result);
		free_during_put_val(dict_val);
		*mem_err = 1;
	}
}
