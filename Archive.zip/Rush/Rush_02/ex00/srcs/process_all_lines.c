/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   process_all_lines.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 19:59:29 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/05 20:11:43 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*read_line(int fd, int *mem_err, int *dict_err);
int		process(char *line, char ***dict_val, int *dict_err, int *mem_err);

void	process_lines(char ***dict_val, int fd, int *dict_err, int *mem_err)
{
	char	*line;

	while (!(*dict_err))
	{
		line = read_line(fd, mem_err, dict_err);
		if (!line)
			break ;
		else if (line[0])
			process(line, dict_val, dict_err, mem_err);
		free(line);
		if (*mem_err)
			return ;
	}
}
