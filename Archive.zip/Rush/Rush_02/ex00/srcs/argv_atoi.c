/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   argv_atoi.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 20:21:30 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/05 20:28:42 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	is_space(unsigned char c);

long long	read_argv(char *str, int *sign, int *arg_err)
{
	long long	ret;
	int			idx;

	ret = 0;
	idx = 0;
	while (is_space((unsigned char)str[idx]))
		idx += 1;
	if (str[idx] == '+')
		idx += 1;
	else if (str[idx] == '-')
	{
		(*sign) *= -1;
		idx += 1;
	}
	while ('0' <= str[idx] && str[idx] <= '9')
	{
		ret = ret * 10 + str[idx++] - '0';
		if (4294967295 < ret)
			*arg_err = 1;
	}
	if (str[idx] == '.')
		*arg_err = 1;
	return (ret);
}

unsigned int	val_atoi(char *str, int *arg_err)
{
	int			sign;
	long long	ret;

	sign = 1;
	ret = read_argv(str, &sign, arg_err);
	ret *= sign;
	if (ret < 0)
		*arg_err = 1;
	return ((unsigned int)(ret * (*arg_err == 0)));
}
