git ls-files -o -i --exclude-standard
