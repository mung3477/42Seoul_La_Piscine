git log -5 --pretty=%H
