#!/bin/sh
decrypted=$(echo $FT_NBR1+$FT_NBR2 | tr "\\" "1" | tr "\'\"\?\!" "0234" | tr "mrdoc" "01234")
echo "obase=13; ibase=5; $decrypted" | bc | tr "01234" "gtaio" | tr "6789ABC" "luSnemf" | tr "5" " "
