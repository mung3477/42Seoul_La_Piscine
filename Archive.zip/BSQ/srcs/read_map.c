/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_map_stdin.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 20:50:00 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 21:50:34 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_map.h"
#include <fcntl.h>

char	*read_line(int fd, t_map *map);
void	set_map_info(int fd, t_map *map);
void	read_map_first_line(int fd, t_map *map);
void	read_map_until_eof(int fd, t_map *map);

t_map	*read_map_stdin(void)
{
	t_map	*map;

	map = create_map();
	if (!map)
		return (0);
	set_map_info(0, map);
	if (map->err)
		return (map);
	read_map_first_line(0, map);
	if (map->err)
		return (map);
	read_map_until_eof(0, map);
	return (map);
}

t_map	*read_map_file(char *pathname)
{
	t_map	*map;
	int		fd;

	fd = open(pathname, O_RDONLY);
	if (fd == -1)
		return (0);
	map = create_map();
	if (!map)
		return (map);
	set_map_info(fd, map);
	if (map->err)
		return (map);
	read_map_first_line(fd, map);
	if (map->err)
		return (map);
	read_map_until_eof(fd, map);
	if (map->err)
		return (map);
	close(fd);
	return (map);
}
