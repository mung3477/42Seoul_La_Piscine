/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   set_map.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 21:14:50 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/09 11:59:39 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_map.h"
#include "ft_string.h"

char	*read_line(int fd, t_map *map);

void	set_map_info(int fd, t_map *map)
{
	char	*line;
	int		line_len;
	int		i;

	line = read_line(fd, map);
	if (map->err)
		return ;
	line_len = strlen_bsq(line);
	if (line_len < 4)
	{
		map->err = 1;
		return ;
	}
	i = line_len - 1;
	map->full = line[i--];
	map->obstacle = line[i--];
	map->empty = line[i--];
	map->m = ft_atoi((char *)line, i);
	if ((map->m <= 0) || (map->full == map->obstacle) \
			|| (map->full == map->empty) || (map->obstacle == map->empty))
	{
		map->err = 1;
		return ;
	}
}

void	read_map_first_line(int fd, t_map *map)
{
	char	*line;
	int		line_len;
	int		i;

	line = read_line(fd, map);
	if (map->err)
		return ;
	line_len = strlen_bsq(line);
	if (!line_len)
	{
		map->err = 1;
		return ;
	}
	map->n = line_len;
	map->map = (char *)malloc(sizeof(char) * (map->m * map->n + 1));
	if (!map->map)
		return ;
	map->map[map->m * map->n] = '\0';
	i = 0;
	while (line[i] && is_valid_map_char(line[i], map))
	{
		map->map[i] = line[i];
		i += 1;
	}
}

void	read_map_until_eof(int fd, t_map *map)
{
	char	*line;
	int		line_read;

	line_read = 1;
	while (1)
	{
		line = read_line(fd, map);
		if (map->err || !line)
			break ;
		else if (line_read >= map->m)
		{
			map->err = 1;
			return ;
		}
		if (!is_valid_map_line(line, map))
		{
			map->err = 1;
			return ;
		}
		if (line_read < map->m)
			strcpy_bsq(&(map->map[line_read * map->n]), line);
		line_read += 1;
	}
}
