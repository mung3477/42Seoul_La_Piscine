/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 21:08:56 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 14:18:11 by jeongble         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_map.h"
#include "ft_string.h"

t_map	*create_map(void)
{
	t_map	*map;

	map = (t_map *)malloc(sizeof(t_map) * 1);
	if (!map)
		return (0);
	map->empty = '\0';
	map->obstacle = '\0';
	map->full = '\0';
	map->m = 0;
	map->n = 0;
	map->map = 0;
	map->err = 0;
	return (map);
}

int	is_valid_map_char(char c, t_map *map)
{
	int	valid;

	valid = (c == map->empty || c == map->obstacle);
	valid = (valid && is_printable(c));
	if (!valid)
		map->err = 1;
	return (valid);
}

int	is_valid_map_line(char *line, t_map *map)
{
	int	i;

	i = -1;
	while (line[++i])
		if (!is_valid_map_char(line[i], map))
			return (0);
	return (i == map->n);
}
