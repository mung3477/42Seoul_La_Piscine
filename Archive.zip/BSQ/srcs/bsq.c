/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bsq.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 20:13:59 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/09 12:02:39 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_map.h"

t_map	*read_map_stdin(void);
t_map	*read_map_file(char *pathname);
int		map_error(t_map *map);
void	map_files(int argc, char *argv[]);

int	main(int argc, char *argv[])
{
	t_map	*map;

	if (argc == 1)
	{
		map = read_map_stdin();
		if (!map || !map->map || map->err)
			return (map_error(map));
		solve(map);
	}
	else
		map_files(argc, argv);
	return (0);
}

void	map_files(int argc, char *argv[])
{
	t_map	*map;
	int		i;

	i = 0;
	while (++i < argc)
	{
		map = read_map_file(argv[i]);
		if (!map || !map->map || map->err)
			map_error(map);
		else
		{
			solve(map);
			if (argc >= 3)
				write(1, "\n", 1);
		}
	}
}

int	map_error(t_map *map)
{
	if (map)
	{
		if (map->map)
			free(map->map);
		free(map);
	}
	return (write(1, "map error\n", 10) == -1);
}
