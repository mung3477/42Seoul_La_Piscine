/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jeongble <jeongble@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 22:14:27 by jeongble          #+#    #+#             */
/*   Updated: 2022/06/08 14:27:16 by jeongble         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_map.h"

void	paint_square(char *numbers, int size, t_map *input)
{
	int		i;
	int		j;
	int		max;
	int		maxindex;
	char	*map;

	map = input->map;
	max = 0;
	i = -1;
	while (++i < size)
	{
		if (*(numbers + i) > max)
		{
			max = *(numbers + i);
			maxindex = i;
		}
	}
	i = -1;
	while (++i < max)
	{
		j = -1;
		while (++j < max)
			*(map + maxindex - (input->n * i) - j) = input->full;
	}
}

void	print_result(t_map *input)
{
	int		i;
	int		n;
	int		m;
	char	*map;

	map = input->map;
	n = input->n;
	m = input->m;
	i = 0;
	while (i < n * m)
	{
		write(1, map + i, 1);
		if (i % n == n - 1)
			write(1, "\n", 1);
		i ++;
	}
}
