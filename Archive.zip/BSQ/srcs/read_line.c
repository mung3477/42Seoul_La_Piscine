/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_line.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 13:52:06 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 21:50:28 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include "ft_queue.h"
#include "ft_map.h"

//	read a line from the file(until newline), and returns it.
//	returns null pointer when read meets EOF.
char	*read_line(int fd, t_map *map)
{
	t_node	*head;
	char	buff[1];
	int		read_result;

	head = 0;
	read_result = 0;
	while (1)
	{
		read_result = read(fd, buff, 1);
		if (read_result <= 0)
			break ;
		if (buff[0] == '\n')
			return (extract_str(head));
		insert(buff[0], &head);
	}
	if (head || read_result == -1)
		map->err = 1;
	delete_all(head);
	return (0);
}
