/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_queue.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 13:51:37 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 14:05:06 by jeongble         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_queue.h"

// if memory was not enough, return 0
int	insert(char c, t_node **head)
{
	t_node	*new;
	t_node	*last;

	last = *head;
	new = (t_node *)malloc(sizeof(t_node) * 1);
	if (!new)
	{
		delete_all(*head);
		return (0);
	}
	new->data = c;
	new->next = 0;
	if (!*head)
		*head = new;
	else
	{
		while (last->next)
			last = last->next;
		last->next = new;
	}
	return (1);
}

char	*extract_str(t_node *head)
{
	t_node	*cur;
	int		size;
	int		idx;
	char	*str;

	cur = head;
	idx = -1;
	size = 0;
	while (cur)
	{
		size += 1;
		cur = cur->next;
	}
	str = (char *)malloc(sizeof(char) * (size + 1));
	if (!str)
		return (0);
	cur = head;
	while (++idx < size)
	{
		str[idx] = cur->data;
		cur = cur->next;
	}
	str[idx] = '\0';
	delete_all(head);
	return (str);
}

void	delete_all(t_node *head)
{
	t_node	*cur;
	t_node	*temp;

	cur = head;
	while (cur)
	{
		temp = cur;
		cur = cur->next;
		free(temp);
	}
}
