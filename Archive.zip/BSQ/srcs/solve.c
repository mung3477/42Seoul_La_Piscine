/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jeongble <jeongble@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 22:16:11 by jeongble          #+#    #+#             */
/*   Updated: 2022/06/08 21:45:54 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_map.h"

char	min3(char *input, int x, int index);
void	solve2(char *numbers, t_map *input);
void	paint_square(char *numbers, int size, t_map *input);
void	print_result(t_map *input);
char	*cton(t_map *input, int size, int *p_mem_err);

void	solve(t_map *input)
{
	int		mem_err;
	char	*numbers;
	int		size;

	mem_err = 0;
	size = (input->m) * (input->n);
	numbers = cton(input, size, &mem_err);
	if (!mem_err)
	{
		solve2(numbers, input);
		paint_square(numbers, size, input);
		free(numbers);
		print_result(input);
	}
	free(input->map);
	free(input);
}

char	*cton(t_map *input, int size, int *p_mem_err)
{
	char	*result;
	char	*map;
	int		i;

	result = (char *)malloc(sizeof(char) * size);
	if (!result)
	{
		*p_mem_err = 1;
		return (0);
	}
	map = input->map;
	i = 0;
	while (i < size)
	{
		if (*(map + i) == input->empty)
			*(result + i) = -1;
		else if (*(map + i) == input->obstacle)
			*(result + i) = 0;
		i ++;
	}
	return (result);
}

void	solve2(char *numbers, t_map *input)
{
	int	i;
	int	j;
	int	index;

	i = -1;
	while (++ i < input->m)
		if (*(numbers + (input->n * i)))
			*(numbers + (input->n * i)) = 1;
	i = 0;
	while (++ i < input->n)
		if (*(numbers + i))
			*(numbers + i) = 1;
	i = 0;
	while (++ i < input->m)
	{
		j = 0;
		while (++ j < input->n)
		{
			index = (input->n * i) + j;
			if (*(numbers + index))
				*(numbers + index) = min3(numbers, input->n, index);
		}
	}
}

char	min3(char *numbers, int n, int index)
{
	char	left;
	char	upleft;
	char	up;
	char	result;

	left = *(numbers + index - 1);
	upleft = *(numbers + index - 1 - n);
	up = *(numbers + index - n);
	if (left <= upleft)
	{
		if (left <= up)
			result = left;
		else
			result = up;
	}
	else
	{
		if (upleft <= up)
			result = upleft;
		else
			result = up;
	}
	return (result + 1);
}
