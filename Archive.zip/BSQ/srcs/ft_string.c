/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_string.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 20:11:12 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 14:12:15 by jeongble         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	strlen_bsq(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i += 1;
	return (i);
}

void	strcpy_bsq(char *dst, char *src)
{
	int	i;

	i = 0;
	while (src[i])
	{
		dst[i] = src[i];
		i += 1;
	}
}

int	ft_atoi(char *str, int last)
{
	int			i;
	int			sign;
	long long	ret;

	i = 0;
	sign = 1;
	ret = 0;
	if (str[i] == '+')
		i += 1;
	else if (str[i] == '-')
	{
		sign = -1;
		i += 1;
	}
	while (i <= last && ('0' <= str[i] && str[i] <= '9'))
		ret = ret * 10 + str[i++] - '0';
	if (i <= last)
		ret = 0;
	return (ret * sign);
}

int	is_printable(char c)
{
	return (' ' <= c && c <= '~');
}
