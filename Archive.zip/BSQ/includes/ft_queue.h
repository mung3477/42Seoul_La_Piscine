/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_queue.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/05 14:22:33 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/07 20:07:12 by wjoung           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_QUEUE_H
# define FT_QUEUE_H

typedef struct s_node
{
	char			data;
	struct s_node	*next;
}	t_node;

int		insert(char c, t_node **p_head);
char	*extract_str(t_node *head);
void	delete_all(t_node *head);

#endif
