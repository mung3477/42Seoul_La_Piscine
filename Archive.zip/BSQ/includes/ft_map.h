/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 20:36:55 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 13:37:27 by jeongble         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_MAP_H
# define FT_MAP_H
# include <stdlib.h>
# include <unistd.h>

typedef struct s_map
{
	char	empty;
	char	obstacle;
	char	full;
	int		m;
	int		n;
	char	*map;
	int		err;
}				t_map;

t_map	*create_map(void);
int		is_valid_map_char(char c, t_map *map);
int		is_valid_map_line(char *line, t_map *map);
void	solve(t_map *input);

#endif
