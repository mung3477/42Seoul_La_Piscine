/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_string.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wjoung <wjoung@student.42.kr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/07 20:08:08 by wjoung            #+#    #+#             */
/*   Updated: 2022/06/08 13:37:46 by jeongble         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_STRING_H
# define FT_STRING_H

int	strlen_bsq(char *str);
int	strcpy_bsq(char *dst, char *src);
int	ft_atoi(char *str, int last);
int	is_printable(char c);

#endif
